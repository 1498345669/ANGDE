'''
Evolutionary Algorithm
'''

import numpy as np
import random
import copy
from all_function import select_function

def get_fitness(x, f):
    fitness = f(x)
    return fitness

class EA():
    def __init__(self, population_size, mutate_strength, seed, F, CR, budget, dimension):

        self.x_fitness = None
        self.population_size = population_size
        self.mutate_strength = mutate_strength
        self.seed = seed
        self.M = int(self.population_size / 2)
        np.random.seed(self.seed)
        self.F = F
        self.budget = budget
        self.CR = CR
        self.dimension = dimension
        self.t = 0
        self.optimizer = None


    def initial(self, x_min, x_max):
        population = np.random.uniform(x_min, x_max, [self.population_size, self.dimension])
        return population

    def Fitness(self, population, f):
        fitness = [self.get_fitness_EA(population[p], f) for p in range(len(population))]
        return fitness

    def get_fitness_EA(self, x, f):
        return get_fitness(x, f)


    def EA_mutate(self, x, population):
        k = np.random.randint(0, len(population), 2)
        N = len(x)
        x[0:N:1] = x[0:N:1] + self.F * (population[k[0]][0:N:1] - population[k[1]][0:N:1])
        return x

    def crossover(self, target, mutant):
        # 交叉操作
        cross_points = np.random.rand(len(target)) < self.CR
        # 至少有一个维度是变异的
        if not np.any(cross_points):
            cross_points[np.random.randint(0, len(target))] = True
        trial = np.where(cross_points, mutant, target)
        return trial


    def p_distance(self, x, y):
        dist = (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
        return dist

    def is_domin(self, x, x_min, x_max):
        for i in range(len(x)):
            if x[i] < x_min or x[i] > x_max:
                if self.p_distance(x[i], x_min) < self.p_distance(x[i], x_max):
                    x[i] = x_min
                else:
                    x[i] = x_max
        return x

    def EA_generate_offspring(self, population, f, x_min, x_max):
        fitness = self.Fitness(population, f)
        best_idx = np.argmin(fitness)
        offspring = np.zeros([self.population_size, self.dimension])
        for i in range(self.population_size):
            offspring[i] = self.is_domin(self.EA_mutate(population[best_idx], population), x_min, x_max)
        return offspring

    def selection(self, population, offspring, f):
        # 合并现有种群和子代种群
        candidate_population = population + offspring
        # 计算合并种群的适应度
        candidate_Fitness = self.Fitness(candidate_population, f)
        # 按照适应度对合并种群进行排序（假设是最小化问题）
        sort = sorted(zip(candidate_population, candidate_Fitness), key=lambda x: x[1], reverse=False)
        # print('sort', sort)

        # 选择适应度最好的个体组成新的种群
        new_population = [individual for individual, fitness in sort[:self.population_size]]

        return new_population

    def EA(self, x_min, x_max, f):
        # 初始化种群
        population = self.initial(x_min, x_max)
        # 计算初始种群的适应度
        fitness = self.Fitness(population, f)
        # 初始化历史记录
        Fitness_all = [fitness]
        Population_all = [population]
        history = [np.min(fitness)]
        best_history = [np.min(fitness)]

        # 进化过程
        while self.t < self.budget:
            # # 生成子代
            # offspring = self.EA_generate_offspring(population, f, x_min, x_max)
            offspring_population = []
            for x in population:
                # x1 = self.update(x, best_x, niche, Fitness, f, f_gradient, x_min, x_max)
                mutant = self.EA_mutate(x, population)
                trial = self.crossover(x, mutant)
                x1 = self.is_domin(trial, x_min, x_max)
                # offspring[i] = trial
                offspring_population.append(x1)
            # 选择新的种群
            population = self.selection(population, offspring_population, f)
            # 更新迭代次数
            self.t += 1
            # 计算新种群的适应度
            fitness = self.Fitness(population, f)
            # 更新历史记录
            Fitness_all.append(fitness)
            Population_all.append(population)
            history.append(np.min(fitness))
            # 更新最佳历史记录
            best_history.append(min(np.min(fitness), best_history[-1]))

        return history, best_history, Fitness_all, Population_all

    # def selection(self, population, offspring, f):
    #     new_x = np.zeros([self.population_size, self.dimension])
    #     fitness = self.Fitness(population, f)
    #     x_idx = np.argsort(fitness)
    #     offspring_fitness = self.Fitness(offspring, f)
    #     off_idx = np.argsort(offspring_fitness)
    #     x_ite = 0
    #     off_ite = 0
    #     for i in range(self.M):
    #         if offspring_fitness[off_idx[off_ite]] < fitness[x_idx[x_ite]]:
    #             new_x[i] = copy.deepcopy(offspring[off_idx[off_ite]])
    #             off_ite += 1
    #         else:
    #             new_x[i] = copy.deepcopy(population[x_idx[x_ite]])
    #             x_ite += 1
    #     for j in range(self.population_size - self.M):
    #         if np.random.rand() < 0.5:
    #             idx = np.random.randint(x_ite + 1, self.population_size)
    #             new_x[self.M + j] = copy.deepcopy(population[x_idx[idx]])
    #         else:
    #             idx = np.random.randint(off_ite + 1, self.population_size)
    #             new_x[self.M + j] = copy.deepcopy(offspring[off_idx[idx]])
    #     population = copy.deepcopy(new_x)
    #     population_backup = copy.deepcopy(population)
    #     return population, population_backup

    # def selection(self, population, offspring, f):
    #     candidate_population = population + offspring
    #     candidate_Fitness = self.Fitness(candidate_population, f)
    #     sort = sorted(zip(candidate_population, candidate_Fitness), key=lambda x: x[1], reverse=False)
    #
    #     new_x = []
    #     for i in range(self.population_size):
    #         new_x.append(sort[i][0])
    #         # matches = np.all(candidate_population == sort[i][0], axis=1)
    #         # index_to_remove = np.where(matches)[0][0]  # 获取匹配行的索引
    #         # candidate_population = np.delete(candidate_population, index_to_remove, axis=0)
    #     #
    #     # for j in range(self.population_size - self.M):
    #     #     # 随机选择一个行索引
    #     #     index = np.random.randint(0, len(candidate_population))
    #     #     # 从candidate_population中选择对应的行
    #     #     new_x.append(candidate_population[index])
    #     return new_x
    #
    # def EA(self, x_min, x_max, f):
    #     population = self.initial(x_min, x_max)
    #     fitness = self.Fitness(population, f)
    #     Fitness_all = [fitness]
    #     Population_all = [population]
    #     history = [np.min(fitness)]
    #     best_history = [np.min(fitness)]
    #     while self.t < self.budget:
    #         offspring = self.EA_generate_offspring(population, f, x_min, x_max)
    #         population = self.selection(population, offspring, f)
    #         # population, population_backup = self.selection(population, offspring, f)
    #         self.t += 1
    #         fitness = self.Fitness(population, f)
    #         Fitness_all.append(fitness)
    #         Population_all.append(population)
    #         history.append(np.min(fitness))
    #         best_history.append(min(np.min(fitness), best_history[-1]))
    #     return history, best_history, Fitness_all, Population_all