import numpy as np


# 定义一个高维函数，这里以一个简单的多峰函数为例
def multimodal_function(x):
    return np.sum(x ** 2)  # 这里使用的是一个简单的多峰函数，实际情况可能更复杂


# 定义蒙特卡洛梯度估计函数
def monte_carlo_gradient_estimate(func, x, epsilon=1e-6, num_samples=1000):
    dim = len(x)
    gradient = np.zeros(dim)

    for _ in range(num_samples):
        # 生成随机扰动
        delta = np.random.normal(scale=epsilon, size=dim)

        # 计算函数在扰动点和原点处的值
        f_delta = func(x + delta)
        f_original = func(x)

        # 根据蒙特卡洛梯度估计公式计算梯度
        gradient += (f_delta - f_original) / epsilon * delta

    return gradient / num_samples


# # 测试
# x = np.array([1.0, 2.0, 3.0])  # 初始化变量
# estimated_gradient = monte_carlo_gradient_estimate(multimodal_function, x)
# print("Estimated Gradient:", estimated_gradient)
