from run_method import RUN



population_size = 10
niche_size = 3
# learning_rate = 0.001
budget = 50
gd_budget = 1
evo_budget = 1
repeat = 30
gradient_thresh = 1e-2
mutate_thresh = 500
mutate_strength = 0.5 #PGD
seed = 2025
pop_strength = 3
mutate_turns = mutate_thresh
if_escape_fitness = 0.1
F = 0.3
fitness_p = 0.5
CR = 0.3
distance_factor_max, distance_factor_min = 1.0, 0.5
F_min, F_max = 0.1, 0.5



dimensions = [2, 10, 100, 500, 1000]
#, 500, 1000, 2000, 5000, 10000]

LR = [0.001, 0.01, 0.1]

function_names = ["Quartic Function", "Styblinski-Tang", "Bent Cigar", "Restrigin", "Rosenbrock", "Sphere", "Shubert",
                  "Griewank", "Ackley", "Schwefel"]

for learning_rate in LR:
    for dimension in dimensions:
        for function_name in function_names:
            figure_save_path = "./results_0911/" + str(learning_rate) + str(function_name)
            print("{} D {}:".format(dimension, function_name))
            RUN(figure_save_path, function_name, population_size, dimension, learning_rate, budget, repeat, seed,
                gradient_thresh, mutate_thresh, mutate_strength, gd_budget, evo_budget, pop_strength,
                mutate_turns, if_escape_fitness, niche_size, F, F_min, F_max, CR, distance_factor_max, distance_factor_min,
                fitness_p)
