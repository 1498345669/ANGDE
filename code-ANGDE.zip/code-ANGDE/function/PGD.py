# coding:utf-8
import numpy as np
# import warnings
# warnings.filterwarnings("ignore")




def get_fitness(x, f):
    fitness = f(x)
    return fitness

def get_gradient(x, f_gradient):
    grad = f_gradient(x)
    return grad


class MGD:
    def __init__(self, learning_rate, budget, population_size, dimension):
        self.learning_rate = learning_rate
        self.budget = budget
        self.population_size = population_size
        self.dimension = dimension
        self.t = 0

    def initial(self, x_min, x_max):
        population = np.random.uniform(x_min, x_max, [self.population_size, self.dimension])
        return population

    def Fitness(self, population, f):
        fitness = [get_fitness(population[p], f) for p in range(len(population))]
        return fitness

    def gd_gradient(self, x, f_gradient):
        grad = get_gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def p_distance(self, x, y):
        dist = (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
        return dist

    def is_domin(self, x, x_min, x_max):
        for i in range(len(x)):
            if x[i] < x_min or x[i] > x_max:
                if self.p_distance(x[i], x_min) < self.p_distance(x[i], x_max):
                    x[i] = x_min
                else:
                    x[i] = x_max
        return x


    def MGD(self, x_min, x_max, f, f_gradient):
        population = self.initial(x_min, x_max)
        fitness = self.Fitness(population, f)

        Fitness_all = [fitness]
        Population_all = [population]
        history = [np.min(fitness)]
        best_history = [np.min(fitness)]

        while self.t < self.budget:
            for p in range(self.population_size):
                x_update = self.gd_gradient(population[p], f_gradient)
                # population[p] = self.gd_gradient(population[p], f_gradient)
                population[p] = self.is_domin(x_update, x_min, x_max)
                # fitness[p] = get_fitness(population[p], f)
            # Population_all.append(population)
            fitness = self.Fitness(population, f)

            Fitness_all.append(fitness)
            history.append(np.min(fitness))
            best_history.append(min(np.min(fitness), best_history[-1]))
            self.t += 1

        return history, best_history, Fitness_all, Population_all


class MPGD:
    def __init__(self, learning_rate, budget, population_size, dimension,
                 mutate_thresh, mutate_strength, gradient_thresh):
        self.learning_rate = learning_rate
        self.budget = budget
        self.population_size = population_size
        self.dimension = dimension
        self.mutate_thresh = mutate_thresh
        self.mutate_strength = mutate_strength
        self.gradient_thresh = gradient_thresh
        self.t = 0

    def initial(self, x_min, x_max):
        population = np.random.uniform(x_min, x_max, [self.population_size, self.dimension])
        return population

    def Fitness(self, population, f):
        fitness = [get_fitness(population[p], f) for p in range(len(population))]
        return fitness

    def mutate(self, x):
        return x + np.random.uniform(-self.mutate_strength, self.mutate_strength, [self.dimension])

    def gd_gradient(self, x, f_gradient):
        grad = get_gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def p_distance(self, x, y):
        dist = (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
        return dist

    def is_domin(self, x, x_min, x_max):
        for i in range(len(x)):
            if x[i] < x_min or x[i] > x_max:
                if self.p_distance(x[i], x_min) < self.p_distance(x[i], x_max):
                    x[i] = x_min
                else:
                    x[i] = x_max
        return x

    def MPGD(self, x_min, x_max, f, f_gradient):
        population = self.initial(x_min, x_max)
        fitness = self.Fitness(population, f)
        Fitness_all = [fitness]
        Population_all = [population]
        history = [np.min(fitness)]
        best_history = [np.min(fitness)]
        # normal PGD
        mutate_index = 0
        mutate_count = 0
        while self.t < self.budget:
            for p in range(self.population_size):
                x_gradient = get_gradient(population[p], f_gradient)
                x_gradient_norm = np.linalg.norm(x_gradient, 2)
                if (x_gradient_norm < self.gradient_thresh) & (self.t - mutate_index > self.mutate_thresh):
                    mutate_index = self.t
                    mutate_count += 1
                    population[p] = self.is_domin(self.mutate(population[p]), x_min, x_max)
                else:
                    population[p] = self.is_domin(self.gd_gradient(population[p], f_gradient), x_min, x_max)
            fitness = self.Fitness(population, f)
            Population_all.append(population)
            Fitness_all.append(fitness)
            history.append(np.min(fitness))
            best_history.append(min(np.min(fitness), best_history[-1]))
            self.t += 1
        return history, best_history, Fitness_all, Population_all

