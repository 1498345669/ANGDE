'''
0717 经典多峰函数实验

动态小生境算法 -- speciation clustering

下降方向
1。 梯度方向
2。差分进化方向（考虑最优值点
3。差分进化方向（随机选取两个方向
'''

import numpy as np
import random
from all_function import select_function

def get_fitness(x, f):
    fitness = f(x)
    return fitness

def get_gradient(x, f_gradient):
    grad = f_gradient(x)
    return grad

class GDE():
    def __init__(self, population_size, dimension, niche_size, budget, F, fitness_p, learning_rate):
        self.population_size = population_size
        self.niche_size = niche_size
        self.dimension = dimension
        self.budget = budget
        self.F = F
        self.M = int(self.population_size / 2)
        self.fitness_p = fitness_p
        self.learning_rate = learning_rate
        self.t = 0

    def initial(self, x_min, x_max):
        population = np.random.uniform(x_min, x_max, [self.population_size, self.dimension])
        return population

    def Fitness(self, population, f):
        fitness = [get_fitness(population[p], f) for p in range(len(population))]
        return fitness

    def Gradient(self, x, f_gradient):
        grad = get_gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def is_domin(self, x, x_min, x_max):
        for i in range(len(x)):
            if x[i] < x_min or x[i] > x_max:
                if self.p_distance(x[i], x_min) < self.p_distance(x[i], x_max):
                    x[i] = x_min
                else:
                    x[i] = x_max
        return x

    def fitness_sort(self, population, f):
        Fitness = self.Fitness(population, f)
        sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_p = sort[0][0]
        return best_p, Fitness, sort

    def p_distance(self, x, y):
        dist = (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
        return dist

    def distance_sort(self, x, population):
        Distance = np.zeros(len(population))
        for i in range(len(population)):
            Distance[i] = self.p_distance(x, population[i])
        sort = sorted(zip(population, Distance), key=lambda x: x[1], reverse=False)
        return sort

    def get_niche(self, population, f):
        Niche = []
        for i in range(int(self.population_size/self.niche_size)):
            best_p, Fitness, Fitness_sort = self.fitness_sort(population, f)
            sort = self.distance_sort(best_p, population)
            population1, niche = [], []
            for j in range(len(sort)):
                population1.append(sort[j][0])
            for k in range(self.niche_size):
                niche.append(sort[k][0])
            Niche.append(niche)
            del population1[:self.niche_size]
            population = population1
        if len(population) != 0:
            Niche.append(population)
        return Niche

    def update1(self, x, f_gradient):
        grad = self.Gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def update2(self, x, best_x, f_gradient):
        grad = self.Gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1] + self.F * (best_x[0:N:1]-x[0:N:1]) #+ self.F * (niche[k[0]][0:N:1] - niche[k[1]][0:N:1])
        return x

    def update3(self, x, population):
        k = np.random.randint(0, len(population), 2)
        N = len(x)
        x[0:N:1] = x[0:N:1] + self.F * (population[k[0]][0:N:1] - population[k[1]][0:N:1])
        return x

    def prob(self, x, Fitness, f):
        p = (f(x) - min(Fitness)) / (max(Fitness) - min(Fitness) + 10e-8)
        return p

    def update(self, x, best_x, population, Fitness, f, f_gradient, x_min, x_max):
        if self.p_distance(x, best_x) == 0:
                x = self.is_domin(self.update1(x, f_gradient), x_min, x_max)
        else:
            p = self.prob(x, Fitness, f)
            if p > self.fitness_p:
                x = self.is_domin(self.update2(x, best_x, f_gradient), x_min, x_max)
            else:
                x = self.is_domin(self.update3(x, population), x_min, x_max)
        return x

    import numpy as np

    import numpy as np

    def selection(self, population, offspring, f):
        candidate_population = np.array(population + offspring)
        candidate_Fitness = self.Fitness(candidate_population, f)
        sorted_indices = np.argsort(candidate_Fitness)  # 获取排序后的索引数组

        new_x = []
        # 选择适应度最好的个体组成新的种群
        for i in range(self.M):
            best_individual_index = sorted_indices[i]
            best_individual = candidate_population[best_individual_index]
            new_x.append(best_individual)
            # 从候选种群中删除已选择的个体
            candidate_population = np.delete(candidate_population, best_individual_index, axis=0)
            # 由于删除了元素，后续索引需要减1
            sorted_indices = [index if index < best_individual_index else index - 1 for index in sorted_indices]

        # 如果需要，从剩余的候选种群中随机选择个体以填满新种群
        for j in range(self.population_size - self.M):
            index = np.random.randint(0, len(candidate_population))
            new_x.append(candidate_population[index])
            # 从候选种群中删除已选择的个体
            candidate_population = np.delete(candidate_population, index, axis=0)

        return new_x
    #
    # def selection(self, population, offspring, f):
    #     candidate_population = population + offspring
    #     candidate_Fitness = self.Fitness(candidate_population, f)
    #     sort = sorted(zip(candidate_population, candidate_Fitness), key=lambda x: x[1], reverse=False)
    #
    #     # new_x = []
    #     # 选择适应度最好的个体组成新的种群
    #     new_x = [individual for individual, fitness in sort[:self.M]]
    #     # for i in range(self.M):
    #     #     new_x.append(sort[i][0])
    #     #     matches = np.any(candidate_population == sort[i][0], axis=1)
    #     #     index_to_remove = np.where(matches)[0][0]  # 获取匹配行的索引
    #     #     candidate_population = np.delete(candidate_population, index_to_remove, axis=0)
    #
    #     for j in range(self.population_size - self.M):
    #         # 随机选择一个行索引
    #         index = np.random.randint(0, len(candidate_population))
    #         # 从candidate_population中选择对应的行
    #         new_x.append(candidate_population[index])
    #     return new_x

        # 剩余的选择使用随机方法
        # k = np.random.randint(0, len(population), 2)
        # for j in range(self.population_size - self.M):
            # if np.random.rand() < 0.5:
            #     idx = np.random.choice(x_idx[self.M:])
            # else:
            #     idx = np.random.choice(off_idx[self.M:])
            # new_x[self.M + j] = population[idx] if np.random.rand() < 0.5 else offspring[idx]



    # def L_select(self, x1, population, offspring_population, f):
    #     d_sort = self.distance_sort(x1, population)
    #     # print(d_sort)
    #     if len(population) == 1:
    #         x_nearest = x1
    #     else:
    #         x_nearest = d_sort[1][0]
    #     if f(x1) <= f(x_nearest):
    #         offspring_population.append(np.array(x1))
    #     else:
    #         offspring_population.append(np.array(x_nearest))
    #     return offspring_population


    def GDE(self, x_min, x_max, f, f_gradient):
        population = self.initial(x_min, x_max)
        fitness = self.Fitness(population, f)
        Fitness_all = [fitness]
        Population_all = [population]
        history = [np.min(fitness)]
        best_history = [np.min(fitness)]
        population = list(population)
        while self.t < self.budget:
            Niche = self.get_niche(population, f)
            offspring_population = []
            for i in range(len(Niche)):
                niche = Niche[i]
                best_x, Fitness, Fitness_sort = self.fitness_sort(niche, f)
                for x in niche:
                    x1 = self.update(x, best_x, niche, Fitness, f, f_gradient, x_min, x_max)
                    offspring_population.append(x1)

            population = self.selection(population, offspring_population, f)
            # population = offspring_population_L

            self.t += 1
            fitness = self.Fitness(population, f)
            Fitness_all.append(fitness)
            Population_all.append(population)
            history.append(np.min(fitness))
            best_history.append(min(np.min(fitness), best_history[-1]))
        return history, best_history, Fitness_all, Population_all




