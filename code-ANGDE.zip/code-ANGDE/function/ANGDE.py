'''
0717 经典多峰函数实验

动态小生境算法 -- speciation clustering

下降方向
1。 梯度方向
2。差分进化方向（考虑最优值点
3。差分进化方向（随机选取两个方向
'''
from sklearn.cluster import KMeans
import numpy as np
import random
from all_function import select_function
from scipy.spatial.distance import pdist, squareform
from scipy.stats import entropy
from scipy.spatial.distance import cdist

def get_fitness(x, f):
    fitness = f(x)
    return fitness

def get_gradient(x, f_gradient):
    grad = f_gradient(x)
    return grad

class INGDE():
    def __init__(self, population_size, dimension, niche_size, budget, F_min, F_max, fitness_p,
                 distance_factor_max, distance_factor_min, learning_rate):
        self.population_size = population_size
        self.niche_size = niche_size
        self.dimension = dimension
        self.budget = budget
        self.F_min = F_min
        self.F_max = F_max
        self.t = 0
        self.distance_factor_min = distance_factor_min
        self.distance_factor_max = distance_factor_max
        # self.distance_factor = self.distance_factor_min + (self.distance_factor_max - self.distance_factor_min)*np.sqrt(self.t/self.budget)
        self.M = int(self.population_size / 2)
        self.fitness_p = fitness_p
        self.learning_rate = learning_rate


    def initial(self, x_min, x_max):
        population = np.random.uniform(x_min, x_max, [self.population_size, self.dimension])
        return population

    def Fitness(self, population, f):
        fitness = [get_fitness(population[p], f) for p in range(len(population))]
        # fitness = [self.new_fitness(p, population) for p in range(len(population))]
        return fitness

    def select_Fitness(self, population, f):
        # fitness = [get_fitness(population[p], f) for p in range(len(population))]
        fitness = [self.new_fitness(p, population) for p in range(len(population))]
        return fitness

    # def function_value(self, population, f):
    #     fitness = [get_fitness(population[p], f) for p in range(len(population))]
    #     return fitness

    def Gradient(self, x, f_gradient):
        grad = get_gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def is_domin(self, x, x_min, x_max):
        for i in range(len(x)):
            if x[i] < x_min or x[i] > x_max:
                if self.p_distance(x[i], x_min) < self.p_distance(x[i], x_max):
                    x[i] = x_min
                else:
                    x[i] = x_max
        return x

    def fitness_sort(self, population, f):
        Fitness = self.Fitness(population, f)
        sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_p = sort[0][0]
        return best_p, Fitness, sort


    #
    # def new_fitness(self, individual_index, population):
    #     individual = population[individual_index]
    #     other_individuals = np.delete(population, individual_index, axis=0)
    #
    #     distances = cdist([individual], other_individuals, metric='euclidean')
    #     mean_distance = np.mean(distances)
    #     std_distance = np.std(distances)
    #
    #     hist, bin_edges = np.histogram(distances, bins=10, density=True)
    #     distance_entropy = entropy(hist)
    #
    #     new_fitness = distance_entropy * (std_distance + 0.00001)
    #     return new_fitness
    #
    # #
    # def calculate_diversity_metrics(self, population):
    #     # 计算个体之间的距离矩阵
    #     distances = pdist(population, metric='euclidean')
    #     distance_matrix = squareform(distances)
    #     # 计算距离均值
    #     mean_distance = np.mean(distances)
    #     # 计算距离方差
    #     variance_distance = np.var(distances)
    #     # 计算距离为0的个体对数
    #     zero_distance_count = np.sum(distances == 0)
    #
    #     # 计算距离分布的熵值
    #     hist, bin_edges = np.histogram(distances, bins='auto', density=True)
    #     distance_entropy = entropy(hist)
    #
    #     return {
    #         'mean_distance': mean_distance,
    #         'variance_distance': variance_distance,
    #         'zero_distance_count': zero_distance_count,
    #         'distance_entropy': distance_entropy
    #     }

    # def p_distance(self, x, y):
    #     dist = (np.square(np.sum((np.array(x) - np.array(y))))) ** 0.5
    #     return dist

    def p_distance(self, x, y):
        dot_product = np.dot(x, y)
        norm_x = np.linalg.norm(x)
        norm_y = np.linalg.norm(y)
        cos_sim = dot_product / (norm_x * norm_y)
        normalized_cos_sim = (cos_sim + 1) / 2
        return normalized_cos_sim

    # def calculate_average_distance(self, population):
    #     """计算种群中所有个体间的平均距离。"""
    #     # sort = self.distance_sort(population[1], population)
    #
    #     Distance, index = [], []
    #     distance_sum = 0
    #     count = 0
    #     for i in range(len(population)):
    #         for j in range(i + 1, len(population)):
    #             distance_ij = self.p_distance(population[i], population[j])
    #             distance_sum += distance_ij
    #             index.append([i,j])
    #             Distance.append(distance_ij)
    #             count += 1
    #     return distance_sum / count if count > 0 else 0

    def calculate_average_similarity(self, population):
        """计算种群中所有个体间的平均余弦相似度。"""
        similarity_sum = 0
        count = 0
        for i in range(len(population)):
            for j in range(i + 1, len(population)):
                similarity_ij = self.p_distance(population[i], population[j])
                similarity_sum += similarity_ij
                count += 1
        return similarity_sum / count if count > 0 else 0

    def get_niche(self, population):
        """根据相似度因子动态设置阈值并划分小生境。"""
        average_similarity = self.calculate_average_similarity(population)
        # distance_factor = self.distance_factor_min + (self.distance_factor_max - self.distance_factor_min) * np.sqrt((self.budget - self.t) / self.budget)
        distance_factor = self.distance_factor_min + (self.distance_factor_max - self.distance_factor_min) * np.sqrt(self.t / self.budget)
        similarity_threshold = average_similarity * distance_factor

        # print('distance_factor:', distance_factor)

        niches = []
        for individual in population:
            niche_found = False
            for niche in niches:
                if self.p_distance(individual, niche[0]) > similarity_threshold:
                    niche.append(individual)
                    niche_found = True
                    break

            if not niche_found:
                niches.append([individual])

        return niches

    # def get_niche(self, population):
    #     """根据距离因子动态设置阈值并划分小生境。"""
    #     average_distance = self.calculate_average_distance(population)
    #     distance_factor = self.distance_factor_min + (self.distance_factor_max - self.distance_factor_min) * np.sqrt(self.t / self.budget)
    #     distance_threshold = average_distance * distance_factor
    #
    #     niches = []
    #     for individual in population:
    #         niche_found = False
    #         for niche in niches:
    #             if self.p_distance(individual, niche[0]) < distance_threshold:
    #                 niche.append(individual)
    #                 niche_found = True
    #                 break
    #
    #         if not niche_found:
    #             niches.append([individual])
    #
    #     return niches


    def update1(self, x, f_gradient):
        grad = self.Gradient(x, f_gradient)
        N = len(x)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def update2(self, x, best_x, f_gradient, F):
        N = len(x)
        x[0:N:1] = x[0:N:1] + F * (best_x[0:N:1]-x[0:N:1])
        grad = self.Gradient(x, f_gradient)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        # x[0:N:1] = self.F * (best_x[0:N:1]-x[0:N:1]) #+ self.F * (niche[k[0]][0:N:1] - niche[k[1]][0:N:1])
        return x

    def update3(self, x, population, best_x, f_gradient, F):
        k = np.random.randint(0, len(population), 2)
        N = len(x)
        x[0:N:1] = x[0:N:1] + F * (best_x[0:N:1]-x[0:N:1]) + F * (population[k[0]][0:N:1] - population[k[1]][0:N:1])
        grad = self.Gradient(x, f_gradient)
        x[0:N:1] = x[0:N:1] - self.learning_rate * grad[0:N:1]
        return x

    def prob(self, x, Fitness, f):
        p = (f(x) - min(Fitness)) / (max(Fitness) - min(Fitness) + 10e-8)
        return p

    def adaptive_F(self, p):
        F = self.F_min + (self.F_max - self.F_min) * p
        return F

    def update(self, x, best_x, population, Fitness, f, f_gradient, x_min, x_max):
        # 计算当前解x的适应度
        fitness_x = f(x)
        # 检查当前解x是否是最佳解
        if self.p_distance(x, best_x) == 0:
            x_update = self.update1(x, f_gradient)
            x_update = self.is_domin(x_update, x_min, x_max)
            fitness_update = f(x_update)
            # print("Update by Adam: before-", fitness_x, ":after-", fitness_update)
            # if fitness_x >= fitness_update:
            return x_update
            # else:
            #     return x
        else:
            # 如果不是最佳解，计算更新概率
            p = self.prob(x, Fitness, f)
            F = self.adaptive_F(p)

            if p > self.fitness_p:
                # 使用update3方法进行随机更新
                x_update = self.update3(x, population, best_x, f_gradient, F)
                x_update = self.is_domin(x_update, x_min, x_max)
                fitness_update = f(x_update)
                # print("Update by random: before-", fitness_x, ":after-", fitness_update)
                # if fitness_x >= fitness_update:
                return x_update
                # else:
                #     return x
            else:
                # 使用update2方法向最佳解更新
                x_update = self.update2(x, best_x, f_gradient, F)
                x_update = self.is_domin(x_update, x_min, x_max)
                fitness_update = f(x_update)
                # print("Update by best: before-", fitness_x, ":after-", fitness_update)
                # if fitness_x >= fitness_update:
                return x_update
                # else:
                #     return x


    def INGDE(self, x_min, x_max, f, f_gradient):
        population = self.initial(x_min, x_max)
        fitness = self.Fitness(population, f)
        Fitness_all = [fitness]
        Population_all = [population]
        history = [np.min(fitness)]
        best_history = [np.min(fitness)]
        niche_fitness_history = []  # 存储每个小生境的适应值历史
        population = list(population)
        Niche_all = []
        num_Niche = []

        while self.t < self.budget:
            Niche = self.get_niche(population)
            Niche_all.append(Niche)
            num_Niche.append(len(Niche))
            offspring_population = []
            niche_fitness = []  # 存储当前代每个小生境的适应值

            for i in range(len(Niche)):
                niche = Niche[i]
                best_x, Fitness, Fitness_sort = self.fitness_sort(niche, f)
                niche_fitness.append(Fitness)  # 存储当前小生境的适应值
                for x in niche:
                    x1 = self.update(x, best_x, niche, Fitness, f, f_gradient, x_min, x_max)
                    offspring_population.append(x1)

            niche_fitness_history.append(niche_fitness)  # 添加当前代的小生境适应值

            population = offspring_population

            self.t += 1
            fitness = self.Fitness(population, f)
            Fitness_all.append(fitness)
            Population_all.append(population)
            history.append(np.min(fitness))
            best_history.append(min(np.min(fitness), best_history[-1]))

        print("num_niche:", num_Niche)

            # print('niche fitness history:', niche_fitness_history)

        # self.plot_fitness_history(best_history)
        return history, best_history, Fitness_all, Population_all, niche_fitness_history, Niche_all, num_Niche



