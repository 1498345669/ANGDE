import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

def draw_f(runtime10D, runtime100D, runtime500D, runtime1000D, fig_name):
    runtime = pd.concat([runtime10D, runtime100D, runtime500D, runtime1000D], axis=1, join="outer")
    labels = ["10", "100", "500", "1000"]
    x = np.arange(len(labels))
    y1 = np.array(runtime10D['runtime'])
    y2 = np.array(runtime100D['runtime'])
    y3 = np.array(runtime500D['runtime'])
    y4 = np.array(runtime1000D['runtime'])
    # width = 0.1
    plt.figure(figsize=(8,6))
    fig, ax = plt.subplots()
    width = 0.12  # 柱状图的宽度

    rects1 = ax.bar(x - 3 * width, np.array(runtime.iloc[0]), width, color="salmon", label='Multi-GD')
    rects2 = ax.bar(x - 2 * width, np.array(runtime.iloc[1]), width, color="cyan", label='Multi-PGD')
    rects3 = ax.bar(x - width, np.array(runtime.iloc[2]), width, color="gold", label='EA')
    rects4 = ax.bar(x, np.array(runtime.iloc[3]), width, color="darkgreen", label='ESGD')
    rects5 = ax.bar(x + width, np.array(runtime.iloc[4]), width, color="royalblue", label='EGD')
    rects6 = ax.bar(x + 2 * width, np.array(runtime.iloc[5]), width, color="lightpink", label='EA_gSBX')
    rects7 = ax.bar(x + 3 * width, np.array(runtime.iloc[6]), width, color="mediumorchid", label='NGDE')

    # rects1 = ax.bar(x - width * 2, np.array(runtime.iloc[0]), width, color="salmon", label='M-GD')
    # rects2 = ax.bar(x - width + 0.01, np.array(runtime.iloc[1]), width, color="cyan", label='M-PGD')
    # rects3 = ax.bar(x + 0.02, np.array(runtime.iloc[2]), width, color="gold", label='EA')
    # rects4 = ax.bar(x + width + 0.03, np.array(runtime.iloc[3]), width, color="darkgreen", label='ESGD')
    # rects5 = ax.bar(x + width * 2 + 0.04, np.array(runtime.iloc[4]), width, color="royalblue", label='EGD')
    # rects6 = ax.bar(x + width * 2, np.array(runtime.iloc[5]), width, color="lightpink", label='EA_gSBX')
    # rects7 = ax.bar(x + width * 3 + 0.05, np.array(runtime.iloc[6]), width, color="mediumorchid", label='NGDE')


    # 为y轴、标题和x轴等添加一些文本。
    plt.tick_params(labelsize=16)
    ax.set_ylabel('Runnning time(min)', fontsize=18)
    ax.set_xlabel('Dimension', fontsize=18)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend(loc='best', fontsize=16)

    fig.tight_layout()
    figure_save_path = r"./runningtime"
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)
    plt.savefig(os.path.join(figure_save_path, fig_name), dpi=300, bbox_inches = 'tight')
    # plt.show()
    # plt.close()


runtime10D = pd.read_csv(r"./results_0109/0.1Ackley/runtime10D.csv",index_col=0)
runtime100D = pd.read_csv(r"./results_0109/0.1Ackley/runtime100D.csv",index_col=0)
runtime500D = pd.read_csv(r"./results_0109/0.1Ackley/runtime500D.csv",index_col=0)
runtime1000D = pd.read_csv(r"./results_0109/0.1Ackley/runtime1000D.csv",index_col=0)
fig_name = "Ackley"
draw_f(runtime10D, runtime100D, runtime500D, runtime1000D, fig_name)


runtime10D = pd.read_csv(r"./results_0109/0.001Griewank/runtime10D.csv", index_col=0)
runtime100D = pd.read_csv(r"./results_0109/0.001Griewank/runtime100D.csv", index_col=0)
runtime500D = pd.read_csv(r"./results_0109/0.001Griewank/runtime500D.csv", index_col=0)
runtime1000D = pd.read_csv(r"./results_0109/0.001Griewank/runtime1000D.csv", index_col=0)
fig_name = "Griewank"
draw_f(runtime10D, runtime100D, runtime500D, runtime1000D, fig_name)



runtime10D = pd.read_csv(r"./results_0109/0.001Bent Cigar/runtime10D.csv",index_col=0)
runtime100D = pd.read_csv(r"./results_0109/0.001Bent Cigar/runtime100D.csv",index_col=0)
runtime500D = pd.read_csv(r"./results_0109/0.001Bent Cigar/runtime500D.csv",index_col=0)
runtime1000D = pd.read_csv(r"./results_0109/0.001Bent Cigar/runtime1000D.csv",index_col=0)
fig_name = "Bent Cigar"
draw_f(runtime10D, runtime100D, runtime500D, runtime1000D, fig_name)


runtime10D = pd.read_csv(r"./results_0109/0.001Restrigin/runtime10D.csv",index_col=0)
runtime100D = pd.read_csv(r"./results_0109/0.001Restrigin/runtime100D.csv",index_col=0)
runtime500D = pd.read_csv(r"./results_0109/0.001Restrigin/runtime500D.csv",index_col=0)
runtime1000D = pd.read_csv(r"./results_0109/0.001Restrigin/runtime1000D.csv",index_col=0)
fig_name = "Restrigin"
draw_f(runtime10D, runtime100D, runtime500D, runtime1000D, fig_name)


runtime10D = pd.read_csv(r"./results_0109/0.1Sphere/runtime10D.csv",index_col=0)
runtime100D = pd.read_csv(r"./results_0109/0.1Sphere/runtime100D.csv",index_col=0)
runtime500D = pd.read_csv(r"./results_0109/0.1Sphere/runtime500D.csv",index_col=0)
runtime1000D = pd.read_csv(r"./results_0109/0.1Sphere/runtime1000D.csv",index_col=0)
fig_name = "Sphere"
draw_f(runtime10D, runtime100D, runtime500D, runtime1000D, fig_name)

runtime10D = pd.read_csv(r"./results_0109/0.001Rosenbrock/runtime10D.csv",index_col=0)
runtime100D = pd.read_csv(r"./results_0109/0.001Rosenbrock/runtime100D.csv",index_col=0)
runtime500D = pd.read_csv(r"./results_0109/0.001Rosenbrock/runtime500D.csv",index_col=0)
runtime1000D = pd.read_csv(r"./results_0109/0.001Rosenbrock/runtime1000D.csv",index_col=0)
fig_name = "Rosenbrock"
draw_f(runtime10D, runtime100D, runtime500D, runtime1000D, fig_name)