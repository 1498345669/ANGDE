import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os


def draw_f(runtime500D, runtime1000D, runtime5000D, runtime10000D, fig_name):
    runtime = pd.concat([runtime500D, runtime1000D, runtime5000D, runtime10000D], axis=1, join="outer")
    labels = ["500", "1000", "5000", "10000"]
    x = np.arange(len(labels))
    y1 = np.array(runtime500D['runtime'])
    y2 = np.array(runtime1000D['runtime'])
    y3 = np.array(runtime5000D['runtime'])
    y4 = np.array(runtime10000D['runtime'])
    width = 0.1
    plt.figure(figsize=(8,6))
    fig, ax = plt.subplots()
    rects1 = ax.bar(x - width*3, np.array(runtime.iloc[0]), width, color = "salmon",label='MGD')
    rects2 = ax.bar(x - width*2+0.01, np.array(runtime.iloc[1]), width, color = "cyan",label='MPGD')
    rects3 = ax.bar(x - width + 0.02, np.array(runtime.iloc[2]), width, color = "gold",label='DE')
    rects4 = ax.bar(x + 0.03, np.array(runtime.iloc[3]), width, color = "darkgreen",label='ESGD')
    rects5 = ax.bar(x + width*1 + 0.04, np.array(runtime.iloc[4]),width, color = "royalblue",label='EGD')
    rects6 = ax.bar(x + width*2 + 0.05, np.array(runtime.iloc[5]), width, color = "lightpink",label='NGDE')
    rects7 = ax.bar(x + width*3 + 0.06, np.array(runtime.iloc[5]), width, color="mediumorchid", label='ANGDE')

    # 为y轴、标题和x轴等添加一些文本。
    plt.tick_params(labelsize=16)
    ax.set_ylabel('Running Time(min)', fontsize=18)
    ax.set_xlabel('Dimension', fontsize=18)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend(loc='best', fontsize=16)

    fig.tight_layout()
    figure_save_path = r"./Runningtime/"
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)
    plt.savefig(os.path.join(figure_save_path, fig_name), dpi=300, bbox_inches = 'tight')
    plt.show()


runtime100D = pd.read_excel(r"./results_0904/0.1Ackley/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.1Ackley/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.1Ackley/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.1Ackley/runtime10000D.xlsx",index_col=0)
fig_name = "Ackley"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)


runtime100D = pd.read_excel(r"./results_0904/0.001Bent Cigar/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.001Bent Cigar/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.001Bent Cigar/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.001Bent Cigar/runtime10000D.xlsx",index_col=0)
fig_name = "Bent Cigar"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)


runtime100D = pd.read_excel(r"./results_0904/0.001Griewank/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.001Griewank/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.001Griewank/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.001Griewank/runtime10000D.xlsx",index_col=0)
fig_name = "Griewank"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)


runtime100D = pd.read_excel(r"./results_0904/0.001Quartic Function/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.001Quartic Function/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.001Quartic Function/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.001Quartic Function/runtime10000D.xlsx",index_col=0)
fig_name = "Quartic Function"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)


runtime100D = pd.read_excel(r"./results_0904/0.001Restrigin/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.001Restrigin/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.001Restrigin/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.001Restrigin/runtime10000D.xlsx",index_col=0)
fig_name = "Restrigin"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)


runtime100D = pd.read_excel(r"./results_0904/0.001Rosenbrock/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.001Rosenbrock/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.001Rosenbrock/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.001Rosenbrock/runtime10000D.xlsx",index_col=0)
fig_name = "Rosenbrock"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)


runtime100D = pd.read_excel(r"./results_0904/0.01Schwefel/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.01Schwefel/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.01Schwefel/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.01Schwefel/runtime10000D.xlsx",index_col=0)
fig_name = "Schwefel"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)


runtime100D = pd.read_excel(r"./results_0904/0.001Shubert/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.001Shubert/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.001Shubert/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.001Shubert/runtime10000D.xlsx",index_col=0)
fig_name = "Shubert"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)



runtime100D = pd.read_excel(r"./results_0904/0.1Sphere/runtime500D.xlsx",index_col=0)
runtime1000D = pd.read_excel(r"./results_0904/0.1Sphere/runtime1000D.xlsx",index_col=0)
runtime5000D = pd.read_excel(r"./results_0904/0.1Sphere/runtime5000D.xlsx",index_col=0)
runtime10000D = pd.read_excel(r"./results_0904/0.1Sphere/runtime10000D.xlsx",index_col=0)
fig_name = "Sphere"
draw_f(runtime100D, runtime1000D, runtime5000D, runtime10000D, fig_name)