import numpy as np
import pandas as pd
import scipy.stats as ss
from PGD import MGD
from EA import EA
from PGD import MPGD
from ESGD import ESGD
from EGD import EGD
from GDE import GDE
from ANGDE import INGDE
# from EA_gSBX import EA_gSBX
from all_function import select_function
from draw_results import draw_results
import time
from new_gradient import monte_carlo_gradient_estimate


def run_method(repeat, budget, history_all, g_history_all):
    history_mean = []
    history_std = []
    history_min = []
    for j in range(budget):
        his = []
        for h in range(len(history_all)):
            his.append(history_all[h][j])
        history_mean.append(np.mean(his))
        history_std.append(np.std(his))
        g_min = []
        for gh in range(len(g_history_all)):
            g_min.append(g_history_all[gh][j])
        history_min.append(min(g_min))
    return history_mean, history_std, history_min

def out_results(history_mean, history_std, history_min):
    mean = history_mean[-1]
    std = history_std[-1]
    best = history_min[-1]
    print("mean:{}; std:{}; best:{}".format(mean, std, best))
    return mean, std, best


def RUN(figure_save_path, function_name, population_size, dimension, learning_rate, budget, repeat, seed,
        gradient_thresh, mutate_thresh, mutate_strength, gd_budget, evo_budget, pop_strength,
        mutate_turns , if_escape_fitness, niche_size, F, F_min, F_max,  CR, distance_factor_max, distance_factor_min, fitness_p):

    # figure_save_path = "./results_0110/" + str(learning_rate) + str(function_name)
    # figure_save_path = "./results_05/" + str(learning_rate) + str(F) + str(function_name)

    f, f_gradient, f_estimate_gradient, x_min, x_max = select_function(function_name)
    # f_gradient = monte_carlo_gradient_estimate()
    # ========================Multi-GD=====================================
    history_all, g_history_all = [], []
    fitness_all, population_all = [], []
    print("Running MGD: ")
    start = time.time()
    for i in range(repeat):
        mgd = MGD(learning_rate, budget, population_size, dimension)
        history, g_history, Fitness, population = mgd.MGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(g_history)
        fitness_all.append(Fitness)
        population_all.append(population)
    end = time.time()
    time_MGD = (end - start)/60

    history_all_MGD, best_history_all_MGD = history_all, g_history_all
    fitness_all_MGD, population_all_MGD = fitness_all, population_all
    history_MGD, history_std_MGD, best_history_MGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_MGD, history_std_MGD, best_history_MGD)

    # # ==========================Multi-PGD===================================
    history_all, g_history_all = [], []
    fitness_all, population_all = [], []
    print("Running PGD: ")
    start = time.time()
    for i in range(repeat):
        mpgd = MPGD(learning_rate, budget, population_size, dimension,
                    mutate_thresh, mutate_strength, gradient_thresh)
        history, best_history, Fitness, population = mpgd.MPGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
        fitness_all.append(Fitness)
        population_all.append(population)
    end = time.time()
    time_MPGD = (end - start) / 60
    history_all_MPGD, best_history_all_MPGD = history_all, g_history_all
    fitness_all_MPGD, population_all_MPGD = fitness_all, population_all
    history_MPGD, history_std_MPGD, best_history_MPGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_MPGD, history_std_MPGD, best_history_MPGD)
    # =============================EA================================
    history_all, g_history_all = [], []
    fitness_all, population_all = [], []
    print("Running EA: ")
    start = time.time()
    for i in range(repeat):
        ea = EA(population_size, mutate_strength, seed, F, CR, budget, dimension)
        history, best_history, Fitness, population = ea.EA(x_min, x_max, f)
        history_all.append(history)
        g_history_all.append(best_history)
        fitness_all.append(Fitness)
        population_all.append(population)
    end = time.time()
    time_EA = (end - start) / 60
    history_all_EA, best_history_all_EA = history_all, g_history_all
    fitness_all_EA, population_all_EA = fitness_all, population_all
    history_EA, history_std_EA, best_history_EA = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_EA, history_std_EA, best_history_EA)
    # # ============================ESGD=================================
    history_all, g_history_all = [], []
    fitness_all, population_all = [], []
    print("Running ESGD: ")
    for i in range(repeat):
        esgd = ESGD(population_size, mutate_strength, learning_rate, seed, budget,
                    gd_budget, evo_budget, dimension)
        history, best_history, Fitness, population = esgd.ESGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
        fitness_all.append(Fitness)
        population_all.append(population)
    end = time.time()
    time_ESGD = (end - start) / 60
    history_all_ESGD, best_history_all_ESGD = history_all, g_history_all
    fitness_all_ESGD, population_all_ESGD = fitness_all, population_all
    history_ESGD, history_std_ESGD, best_history_ESGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_ESGD, history_std_ESGD, best_history_ESGD)
    # # =============================EGD================================
    history_all, g_history_all = [], []
    fitness_all, population_all = [], []
    print("Running EGD: ")
    start = time.time()
    for i in range(repeat):
        egd = EGD(population_size, dimension, pop_strength, mutate_strength, if_escape_fitness,
                  budget, gradient_thresh, mutate_thresh, learning_rate, mutate_turns)
        history, best_history, Fitness, population = egd.EGD(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
        fitness_all.append(Fitness)
        population_all.append(population)
    end = time.time()
    time_EGD = (end - start) / 60
    history_all_EGD, best_history_all_EGD = history_all, g_history_all
    fitness_all_EGD, population_all_EGD = fitness_all, population_all
    history_EGD, history_std_EGD, best_history_EGD = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_EGD, history_std_EGD, best_history_EGD)
    # # ===============================DE_gSBX=========================================
    # history_all, g_history_all = [], []
    # fitness_all, population_all = [], []
    # print("Running EA_gSBX: ")
    # start = time.time()
    # for i in range(repeat):
    #     ea = INGDE(population_size, mutate_strength, seed, budget, dimension, learning_rate)
    #     history, best_history, Fitness, population = ea.INGDE(x_min, x_max, f, f_gradient)
    #     history_all.append(history)
    #     g_history_all.append(best_history)
    #     fitness_all.append(Fitness)
    #     population_all.append(population)
    # end = time.time()
    # time_EA_gSBX = (end - start) / 60
    # history_all_EA_gSBX, best_history_all_EA_gSBX = history_all, g_history_all
    # fitness_all_EA_gSBX, population_all_EA_gSBX = fitness_all, population_all
    # history_EA_gSBX, history_std_EA_gSBX, best_history_EA_gSBX = run_method(repeat, budget, history_all, g_history_all)
    # out_results(history_EA_gSBX, history_std_EA_gSBX, best_history_EA_gSBX)

    # ===============================GDE=========================================
    history_all, g_history_all = [], []
    fitness_all, population_all = [], []
    print("Running GDE: ")
    start = time.time()
    for i in range(repeat):
        gde = GDE(population_size, dimension, niche_size, budget, F, fitness_p, learning_rate)
        history, best_history, Fitness, population = gde.GDE(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
        fitness_all.append(Fitness)
        population_all.append(population)
    end = time.time()
    time_GDE = (end - start) / 60
    history_all_GDE, best_history_all_GDE = history_all, g_history_all
    fitness_all_GDE, population_all_GDE = fitness_all, population_all
    history_GDE, history_std_GDE, best_history_GDE = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_GDE, history_std_GDE, best_history_GDE)
    # ===============================GDE=========================================
    history_all, g_history_all = [], []
    fitness_all, population_all = [], []
    print("Running INGDE: ")
    start = time.time()
    for i in range(repeat):
        ingde = INGDE(population_size, dimension, niche_size, budget, F_min, F_max,  fitness_p, distance_factor_max, distance_factor_min, learning_rate)
        history, best_history, Fitness, population, niche_fitness_history_INGDE, Niche_all_INGDE, num_niche_INGDE = ingde.INGDE(x_min, x_max, f, f_gradient)
        history_all.append(history)
        g_history_all.append(best_history)
        fitness_all.append(Fitness)
        population_all.append(population)
    end = time.time()
    time_INGDE = (end - start) / 60
    history_all_INGDE, best_history_all_INGDE = history_all, g_history_all
    fitness_all_INGDE, population_all_INGDE = fitness_all, population_all
    history_INGDE, history_std_INGDE, best_history_INGDE = run_method(repeat, budget, history_all, g_history_all)
    out_results(history_INGDE, history_std_INGDE, best_history_INGDE)
    # ==================================draw-results=========================================
    list_history = [history_MGD, history_MPGD, history_EA, history_ESGD, history_EGD,  history_GDE, history_INGDE]
    draw_results(list_history, function_name, dimension, figure_save_path)

    function_name_best = function_name + " best"
    list_best_history = [best_history_MGD, best_history_MPGD, best_history_EA,
                         best_history_ESGD, best_history_EGD, best_history_GDE, best_history_INGDE]
    draw_results(list_best_history, function_name_best, dimension, figure_save_path)

    # ==================================niche=========================================
    path = figure_save_path + "/niche_fitness" + str(dimension) + "D" + ".xlsx"
    pd.DataFrame(niche_fitness_history_INGDE).to_excel(path)

    path = figure_save_path + "/niche" + str(dimension) + "D" + ".xlsx"
    pd.DataFrame(Niche_all_INGDE).to_excel(path)

    path = figure_save_path + "/num_niche" + str(dimension) + "D" + ".xlsx"
    pd.DataFrame(num_niche_INGDE).to_excel(path)

    # ==================================time====================
    run_time = [[time_MGD], [time_MPGD], [time_EA], [time_ESGD], [time_EGD],[time_GDE],[time_INGDE]]
    print("runtime:")
    print("MGD: {}min; MPGD: {}min; EA:{}; ESGD: {}min; EGD:{}min; GDE: {}min; ANGDE:{}min".format(run_time[0][0],run_time[1][0],run_time[2][0],
                                                                                      run_time[3][0], run_time[4][0],run_time[5][0],run_time[6][0]))

    index = ["MGD", "MPGD", "EA", "ESGD", "EGD", "NGDE" ,"ANGDE"]
    columns = ["runtime"]
    running_time = pd.DataFrame(run_time, index=index, columns=columns)
    path = figure_save_path + "/runtime" + str(dimension) + "D" + ".xlsx"
    running_time.to_excel(path)
    # ==================================store=========================================
    pd_MGD = pd.DataFrame([history_MGD], index=["MGD"])
    pd_MPGD = pd.DataFrame([history_MPGD], index=["MPGD"])
    pd_EA = pd.DataFrame([history_EA], index=["EA"])
    pd_ESGD = pd.DataFrame([history_ESGD], index=["ESGD"])
    pd_EGD = pd.DataFrame([history_EGD], index=["EGD"])
    pd_ANGDE = pd.DataFrame([history_INGDE], index=["INGDE"])
    pd_NGDE = pd.DataFrame([history_GDE], index=["NGDE"])
    history = pd.concat([pd_MGD, pd_MPGD, pd_EA, pd_ESGD, pd_EGD, pd_NGDE, pd_ANGDE])
    path = figure_save_path + "/results_history" + str(dimension) + "D" + ".xlsx"
    history.to_excel(path)

    pd_MGD = pd.DataFrame([best_history_MGD], index=["MGD"])
    pd_MPGD = pd.DataFrame([best_history_MPGD], index=["MPGD"])
    pd_EA = pd.DataFrame([best_history_EA], index=["EA"])
    pd_ESGD = pd.DataFrame([best_history_ESGD], index=["ESGD"])
    pd_EGD = pd.DataFrame([best_history_EGD], index=["EGD"])
    pd_ANGDE = pd.DataFrame([best_history_INGDE], index=["ANGDE"])
    pd_NGDE = pd.DataFrame([best_history_GDE], index=["NGDE"])
    best_history = pd.concat([pd_MGD, pd_MPGD, pd_EA, pd_ESGD, pd_EGD, pd_NGDE, pd_ANGDE])
    path = figure_save_path + "/results_best_history" + str(dimension) + "D" + ".xlsx"
    best_history.to_excel(path)

    pd_MGD = pd.DataFrame([history_std_MGD], index=["GD"])
    pd_MPGD = pd.DataFrame([history_std_MPGD], index=["PGD"])
    pd_EA = pd.DataFrame([history_std_EA], index=["DE"])
    pd_ESGD = pd.DataFrame([history_std_ESGD], index=["ESGD"])
    pd_EGD = pd.DataFrame([history_std_EGD], index=["EGD"])
    pd_ANGDE = pd.DataFrame([history_std_INGDE], index=["ANGDE"])
    pd_NGDE = pd.DataFrame([history_std_GDE], index=["NGDE"])
    std_history = pd.concat([pd_MGD, pd_MPGD, pd_EA, pd_ESGD, pd_EGD, pd_NGDE, pd_ANGDE])
    path = figure_save_path + "/results_history_std" + str(dimension) + "D" + ".xlsx"
    std_history.to_excel(path)

    pd_all_MGD = pd.DataFrame([history_all_MGD], index=["MGD"])
    pd_all_MPGD = pd.DataFrame([history_all_MPGD], index=["MPGD"])
    pd_all_EA = pd.DataFrame([history_all_EA], index=["EA"])
    pd_all_ESGD = pd.DataFrame([history_all_ESGD], index=["ESGD"])
    pd_all_EGD = pd.DataFrame([history_all_EGD], index=["EGD"])
    pd_all_ANGDE = pd.DataFrame([history_all_INGDE], index=["ANGDE"])
    pd_all_NGDE = pd.DataFrame([history_all_GDE], index=["NGDE"])
    history = pd.concat([pd_all_MGD, pd_all_MPGD, pd_all_EA, pd_all_ESGD, pd_all_EGD, pd_all_NGDE, pd_all_ANGDE])
    path = figure_save_path + "/results_all_history" + str(dimension) + "D" + ".xlsx"
    history.to_excel(path)

    pd_all_MGD = pd.DataFrame([best_history_all_MGD], index=["MGD"])
    pd_all_MPGD = pd.DataFrame([best_history_all_MPGD], index=["MPGD"])
    pd_all_EA = pd.DataFrame([best_history_all_EA], index=["EA"])
    pd_all_ESGD = pd.DataFrame([best_history_all_ESGD], index=["ESGD"])
    pd_all_EGD = pd.DataFrame([best_history_all_EGD], index=["EGD"])
    pd_all_ANGDE = pd.DataFrame([best_history_INGDE], index=["ANGDE"])
    pd_all_NGDE = pd.DataFrame([best_history_all_GDE], index=["NGDE"])
    best_history = pd.concat([pd_all_MGD, pd_all_MPGD, pd_all_EA, pd_all_ESGD, pd_all_EGD, pd_all_NGDE, pd_all_ANGDE])
    path = figure_save_path + "/results_best_all_history" + str(dimension) + "D" + ".xlsx"
    best_history.to_excel(path)

    pd_all_MGD = pd.DataFrame([population_all_MGD], index=["MGD"])
    pd_all_MPGD = pd.DataFrame([population_all_MPGD], index=["MPGD"])
    pd_all_EA = pd.DataFrame([population_all_EA], index=["EA"])
    pd_all_ESGD = pd.DataFrame([population_all_ESGD], index=["ESGD"])
    pd_all_EGD = pd.DataFrame([population_all_EGD], index=["EGD"])
    pd_all_ANGDE = pd.DataFrame([population_all_INGDE], index=["ANGDE"])
    pd_all_NGDE = pd.DataFrame([population_all_GDE], index=["NGDE"])
    history = pd.concat([pd_all_MGD, pd_all_MPGD, pd_all_EA, pd_all_ESGD, pd_all_EGD, pd_all_NGDE, pd_all_ANGDE])
    path = figure_save_path + "/results_population_all_history" + str(dimension) + "D" + ".xlsx"
    history.to_excel(path)

    pd_all_MGD = pd.DataFrame([fitness_all_MGD], index=["MGD"])
    pd_all_MPGD = pd.DataFrame([fitness_all_MPGD], index=["MPGD"])
    pd_all_EA = pd.DataFrame([fitness_all_EA], index=["EA"])
    pd_all_ESGD = pd.DataFrame([fitness_all_ESGD], index=["ESGD"])
    pd_all_EGD = pd.DataFrame([fitness_all_EGD], index=["EGD"])
    pd_all_ANGDE = pd.DataFrame([fitness_all_INGDE], index=["ANGDE"])
    pd_all_NGDE = pd.DataFrame([fitness_all_GDE], index=["NGDE"])
    best_history = pd.concat([pd_all_MGD, pd_all_MPGD, pd_all_EA, pd_all_ESGD, pd_all_EGD, pd_all_NGDE, pd_all_ANGDE])
    path = figure_save_path + "/results_fitness_all_history" + str(dimension) + "D" + ".xlsx"
    best_history.to_excel(path)

    # ==================================test=========================================
    res1 = ss.ranksums(history_MGD, history_INGDE)
    res2 = ss.ranksums(history_MPGD, history_INGDE)
    res3 = ss.ranksums(history_EA, history_INGDE)
    res4 = ss.ranksums(history_ESGD, history_INGDE)
    res5 = ss.ranksums(history_EGD, history_INGDE)
    res6 = ss.ranksums(history_GDE, history_INGDE)
    print("compared with ANGDE(rank sum)")
    print("GD:", res1.pvalue)
    print("PGD:", res2.pvalue)
    print("DE:", res3.pvalue)
    print("ESGD:", res4.pvalue)
    print("EGD:", res5.pvalue)
    print("NGDE:", res6.pvalue)
    res = [[res1.pvalue], [res2.pvalue], [res3.pvalue], [res4.pvalue], [res5.pvalue], [res6.pvalue]]
    index = ["MGD", "MPGD", "EA", "ESGD", "EGD", "NGDE"]
    columns = ["ranksums"]
    data_res = pd.DataFrame(res, index=index, columns=columns)
    path = figure_save_path + "/ransums" + str(dimension) + "D" + ".xlsx"
    data_res.to_excel(path)
