import numpy as np
from draw import draw_pic, draw_pic_3D, get_x_and_y
import random

### 1D

# # Equal_maxima
# # local:5 global:1
# def f1(x_min=0, x_max=1, y_min=0, y_max=1):
#     x = np.linspace(0, 1, 1000)
#     y = np.sin(5 * np.pi * x) ** 6
#     title = 'F1'
#     return x, y, title, x_min, x_max, y_min, y_max
# #Equal_maxima
# x, y, title, x_min, x_max, y_min, y_max = f1()
# fig_path = "./"
# draw_pic(x, y, title, x_min, x_max, y_min, y_max, fig_path)
#
#
# # Uneven_decreasing_maxima
# # global:4 local:1
# def f2(x_min=0, x_max=1, y_min=0, y_max=1):
#     x = np.linspace(0, 1, 1000)
#     y = np.exp(-2 * np.log(2) * ((x - 0.08) / 0.854) ** 2) * (np.sin(5 * np.pi * (x ** (3 / 4)) - 0.05)) ** 6
#     title = 'F2'
#     return x, y, title, x_min, x_max, y_min, y_max
# #Uneven_decreasing_maxima
# x, y, title, x_min, x_max, y_min, y_max = f2()
# fig_path = "./" + title
# draw_pic(x, y, title, x_min, x_max, y_min, y_max, fig_path)
#
#
### 2D
# Himmelblau
# golbal:4 local:0
def f3(z_min=-2000, z_max=0, offset=-2000):
    x, y = get_x_and_y(-6, 6, -6, 6)
    z = (200 - (x ** 2 + y - 11) ** 2 - (x + y ** 2 - 7) ** 2)
    title = 'Himmelblau'
    return x, y, z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f3()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Six_hump_camel_back
# golbal:2 local:2
def f4(z_min=-1, z_max=3, offset=-1):
    x, y = get_x_and_y(-1, 1, -1, 1)
    z = 4 * x**2 - 2.1 * x**4 + (x**6) / 3 + x * y - 4 * (y ** 2) + 4 * (y ** 4)
    title = 'Six_hump_camel_back'
    return x, y, z, title, z_min, z_max, offset

x, y, z, title, z_min, z_max, offset = f4()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)


# Three-Hump Camel
def f4(z_min=-1, z_max=3, offset=-1):
    x, y = get_x_and_y(-1, 1, -1, 1)
    z = 2*x**2 - 1.05*x**4 + (x**6)/6 + x*y + y**2
    title = 'Three-Hump Camel'
    return x, y, z, title, z_min, z_max, offset

x, y, z, title, z_min, z_max, offset = f4()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Shubert
# global:D*3^D local:many
def f5(z_min=-300, z_max=200, offset=-300):
    x, y = get_x_and_y(-10, 10, -10, 10)
    z1 = (1 * np.cos((1 + 1) * x + 1)) + (2 * np.cos((2 + 1) * x + 2)) + (3 * np.cos((3 + 1) * x + 3)) + (
            4 * np.cos((4 + 1) * x + 4)) + (5 * np.cos((5 + 1) * x + 5))
    z2 = (1 * np.cos((1 + 1) * y + 1)) + (2 * np.cos((2 + 1) * y + 2)) + (3 * np.cos((3 + 1) * y + 3)) + (
            4 * np.cos((4 + 1) * y + 4)) + (5 * np.cos((5 + 1) * y + 5))
    z = -(z1 * z2)
    title = 'Shubert'
    return x, y, z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f5()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)


# Bent Cigar Function
def f6(z_min = 0,z_max = 400,offset = 0):
    x, y = get_x_and_y(-2, 2, -2, 2)
    z = x * x + 100 * y * y
    title = 'Bent Cigar Function'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f6()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Sphere Function
def f7(z_min = 0,z_max = 25,offset = 0):
    x,y = get_x_and_y(-3,3,-3,3)
    z = x ** 2 + y ** 2
    title = 'Sphere Function'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f7()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)


# Zakharov Function:
def f8(z_min = 0,z_max = 500,offset = 0):
    x,y = get_x_and_y(-3,3,-3,3)
    z1 = x ** 2 + y ** 2
    z21 = 0.5 * x + 0.5 * 2 * y
    z2 = z21 ** 2 + z21 ** 4
    z = z1 + z2
    title = 'Zakharov '
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f8()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Rosenbrock Function:
def f9(z_min = 0,z_max = 3500,offset = 0):
    x,y = get_x_and_y(-2,2,-2,2)
    z = 100 * (x ** 2 - y) ** 2 + (x - 1) ** 2
    title = 'Rosenbrock'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f9()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Ackley Function:
def f10(z_min = 0,z_max = 20,offset = 0):
    x,y = get_x_and_y(-10,10,-10,10)
    smsq = x * x + y * y
    smcs = np.cos((2 * np.pi) * x) + np.cos((2 * np.pi) * y)
    inx = 1 / 2
    z = -20 * np.exp(-0.2 * np.sqrt(inx * smsq)) - np.exp(inx * smcs) + 20 + np.e
    title = 'Ackley'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f10()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

#Griewank Function:
def f11(z_min = 0,z_max = 2,offset = 0):
    x,y = get_x_and_y(-10,10,-10,10)
    z1 = (x * x + y * y)/4000
    z2 = np.cos(x / np.sqrt(1)) * np.cos(y / np.sqrt(2))
    z = z1 - z2 + 1
    title = 'Griewank'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f11()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Restrigin function
def f12(z_min=0, z_max=80, offset=0):
    x, y = get_x_and_y(-5.12, 5.12, -5.12, 5.12)
    z = 2 * 10 + x ** 2 - 10 * np.cos(2 * np.pi * x) + y ** 2 - 10 * np.cos(2 * np.pi * y)
    title = 'Restrigin'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f12()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Vincent function
def f13(z_min=-1, z_max=1.5, offset=-1):
    x, y = get_x_and_y(0.25, 10, 0.25, 10)
    z = (np.sin(10 * np.log(x)) + np.sin(10 * np.log(y))) / 2
    title = 'Vincent'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f13()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# Michalewicz function
def f14(z_min=-2, z_max=1, offset=-2):
    x, y = get_x_and_y(0, 4, 0, 4)
    z = - np.sin(x) * (np.sin(x**2 / np.pi))**20 - np.sin(y) * (np.sin(2*y**2 / np.pi))**20
    title = 'Michalewicz'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f14()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)


# Styblinski-Tang function
def f15(z_min=-100, z_max=250, offset=-100):
    x, y = get_x_and_y(-5, 5, -5, 5)
    z = (x ** 4 - 16 * x ** 2 + 5 * x)/2 + (y ** 4 - 16 * y ** 2 + 5 * y)/2
    title = 'Styblinski-Tang'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f15()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)

# # Styblinski-Tang function
# def f16(z_min=0, z_max=100, offset=0):
#     x, y = get_x_and_y(-5, 5, -5, 5)
#     z = (x ** 4 - 16 * x ** 2 + 5 * x)/2 + (y ** 4 - 16 * y ** 2 + 5 * y)/2
#     title = 'Styblinski-Tang'
#     return x,y,z, title, z_min, z_max, offset
# x, y, z, title, z_min, z_max, offset = f16()
# fig_path = "./" + title
# draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)


# Quartic Function
def f17(z_min=0, z_max=5, offset=0):
    x, y = get_x_and_y(-1, 1, -1, 1)
    z = x**4 + random.random() + 2*y**4 + random.random()
    title = 'Quartic Function'
    return x,y,z, title, z_min, z_max, offset
x, y, z, title, z_min, z_max, offset = f17()
fig_path = "./" + title
draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path)



#
#
all_function = ["Equal_maxima", "Uneven_decreasing_maxima",
                "Himmelblau", "Six_hump_camel_back", "Shubert",
                "Bent Cigar", "Sphere", "Zakharov",
                "Rosenbrock", "Ackley", "Griewank", "Restrigin"]


function_1D = ["Equal_maxima", "Uneven_decreasing_maxima"]
function_2D = ["Himmelblau", "Six_hump_camel_back", "Shubert"]
function_MD = ["Bent Cigar", "Sphere", "Zakharov",
               "Rosenbrock", "Ackley", "Griewank", "Restrigin"]


# f1()