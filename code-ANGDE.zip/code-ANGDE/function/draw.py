import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import os


def get_x_and_y(x_min, x_max, y_min, y_max):
    x = np.arange(x_min, x_max, 0.1)
    y = np.arange(y_min, y_max, 0.1)
    x, y = np.meshgrid(x, y)  # 生成网格点坐标矩阵
    return x, y

def draw_pic(x, y, title, x_min, x_max, y_min, y_max, fig_path):
    plt.grid(True)  ##增加格点
    plt.xlim(x_min, x_max)
    plt.ylim(y_min, y_max)
    plt.title(title)
    plt.plot(x, y)
    fig_path = "function_fig"  # 这里创建了一个文件夹，如果依次创建不同文件夹，可以用name_list[i]
    if not os.path.exists(fig_path):
        os.makedirs(fig_path)  # 如果不存在目录figure_save_path，则创建
    plt.savefig(os.path.join(fig_path, title), dpi=300)  # 分别命名图片
    plt.close()

def draw_pic_3D(x, y, z, title, z_min, z_max, offset, fig_path):
    fig = plt.figure()
    ax = Axes3D(fig)
    # rstride代表row行步长  cstride代表colum列步长  camp 渐变颜色
    ax.plot_surface(x, y, z, rstride=1, cstride=1, cmap = plt.get_cmap('rainbow'),color='orangered')
    # 绘制等高线
    ax.contour(x,y,z,offset=offset,colors='green')
    ax.set_zlim(z_min, z_max)
    ax.set_title(title)
    fig_path = "function_fig"  # 这里创建了一个文件夹，如果依次创建不同文件夹，可以用name_list[i]
    if not os.path.exists(fig_path):
        os.makedirs(fig_path)  # 如果不存在目录figure_save_path，则创建
    plt.savefig(os.path.join(fig_path, title), dpi=300)  # 分别命名图片
    plt.close()