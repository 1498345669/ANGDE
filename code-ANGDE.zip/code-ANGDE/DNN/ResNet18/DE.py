import copy
import random
import time
import torch
from get_fitness import *
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from checkpoint import save_checkpoint

class DE():

    def __init__(self, trainloader, testloader, valloader, criterion,
                 population_size, F, num_epoch):
        # self.optimizer = optimizer
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.trainloader = trainloader
        self.testloader = testloader
        self.valloader = valloader
        self.device = device
        self.criterion = criterion
        self.lambda_reg = 0.001
        self.F = F
        self.population_size = population_size
        self.num_epoch = num_epoch
        self.testloader = testloader
        self.t = 0

    # 定义计算损失函数
    def calculate_loss(self, model, inputs, targets):
        outputs = model(inputs)
        loss = self.criterion(outputs, targets)
        # 计算L2正则化项
        l2_reg = torch.tensor(0., requires_grad=True).to(self.device)
        for param in model.parameters():
            l2_reg = l2_reg + torch.norm(param, 2)
        # 将L2正则化项加入到损失中
        loss = loss + (self.lambda_reg / 2) * l2_reg
        return loss, outputs



    # 定义评估模型函数
    def evaluate_model(self, model, dataloader):
        model.eval()
        total_loss = 0
        correct = 0
        total = 0

        with torch.no_grad():
            for inputs, targets in dataloader:
                inputs, targets = inputs.to(self.device), targets.to(self.device)
                loss, outputs = self.calculate_loss(model, inputs, targets)
                # 计算L2正则化项
                l2_reg = torch.tensor(0., requires_grad=True).to(self.device)
                for param in model.parameters():
                    l2_reg = l2_reg + torch.norm(param, 2)
                # 将L2正则化项加入到损失中
                loss = loss + (self.lambda_reg / 2) * l2_reg
                total_loss += loss.item()
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()

        avg_loss = total_loss / len(dataloader)
        accuracy = 100.0 * correct / total

        return avg_loss, accuracy

    def DE_update(self, population, model, best_model, F):

        model.train()
        start_time = time.time()

        with torch.no_grad():
            j, k = random.sample(range(self.population_size), 2)
            xj, xk = population[j].parameters(), population[k].parameters()
            for param, best_param, param_j, param_k in zip(model.parameters(), best_model.parameters(), xj, xk):
                param.data = param.data + F * (best_param.data - param.data) + F * (param_j.data - param_k.data)
        end_time = time.time()
        epoch_time = end_time - start_time

        return model, epoch_time

    # def get_loss(self, model, loader):
    #     model.eval()
    #     test_loss = 0
    #     correct = 0
    #     total = 0
    #
    #     with torch.no_grad():
    #         for batch_idx, (inputs, targets) in enumerate(loader):
    #             inputs, targets = inputs.to(self.device), targets.to(self.device)
    #             outputs = model(inputs)
    #             loss = self.criterion(outputs, targets)
    #
    #             test_loss += loss.item()
    #             _, predicted = outputs.max(1)
    #             total += targets.size(0)
    #             correct += predicted.eq(targets).sum().item()
    #     test_loss /= len(loader)
    #     return test_loss

    def fitness(self, population):
        Fitness = [get_loss(model, self.valloader, self.device, self.criterion) for model in population]
        return Fitness

    def fitness_sort(self, population):
        Fitness = self.fitness(population)
        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_individual = Fitness_sort[0][0]
        return best_individual, Fitness, Fitness_sort

    def select(self,  Fitness_sort):
        # 选择前50%最优个体和随机选取50%个体作为下一代
        next_generation = []
        new_fitness = []
        num_best_selected = self.population_size // 2
        num_random_selected = self.population_size - num_best_selected

        # 选择前50%最优个体
        next_generation.extend([individual for individual, fitness in Fitness_sort[0:num_best_selected]])
        new_fitness.extend([fitness for individual, fitness in Fitness_sort[0:num_best_selected]])

        # 随机选取50%个体
        remaining_individuals = [individual for individual, fitness in Fitness_sort[num_best_selected:]]
        remaining_fitness = [fitness for individual, fitness in Fitness_sort[num_best_selected:]]
        random_indices = np.random.choice(len(remaining_individuals), num_random_selected, replace=False)
        next_generation.extend([remaining_individuals[i] for i in random_indices])
        new_fitness.extend([remaining_fitness[i] for i in random_indices])

        # 更新种群
        population = next_generation
        return population, new_fitness

    def weight_l1(self, model):
        # 计算L1正则化项
        l1_reg = torch.tensor(0., requires_grad=True).to(self.device)
        for param in model.parameters():
            l1_reg = l1_reg + torch.norm(param, 1)
        return l1_reg

    def weight_l0(self, model, threshold):
        l0_norm = 0
        total_elements = 0

        for param in model.parameters():
            total_elements += param.nelement()
            temp_param = param.data.clone()
            temp_param[temp_param.abs() < threshold] = 0
            l0_norm += (temp_param != 0).sum().item()
        l0_norm = l0_norm / total_elements if total_elements > 0 else 0

        return l0_norm

    def calculate_sparsity(self, individual):
        total_weights = 0
        zero_weights = 0
        for param in individual.parameters():
            total_weights += param.numel()
            zero_weights += torch.sum(param == 0).item()

        sparsity = zero_weights / total_weights
        return sparsity


    def DE(self, optimizers, population, prune_threshold):

        # 训练模型
        train_losses_all, test_losses_all = [], []
        train_accs_all, test_accs_all = [], []
        valid_losses_all, valid_accs_all = [], []
        epoch_times_all, Weight_individual_all, Sparsity_weight_all = [], [], []

        Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list = [], [], [], [], [], []
        times, Weight_epoch, Sparsity_weight = [], [], []

        best_individual, Fitness, Fitness_sort = self.fitness_sort(population)
        print("Fitness:", Fitness)
        while self.t < self.num_epoch:
            print(f"Epoch [{self.t + 1}/{self.num_epoch}]")
            loss = []
            updated_population = []
            train_losses, test_losses = [], []
            train_accs, test_accs = [], []
            valid_losses, valid_accs = [], []
            epoch_times, Weight_individual, Sparsity_weight_individual = [], [],[]

            begin_time = time.time()
            offspring_population = population
            best_individual, Fitness, Fitness_sort = self.fitness_sort(population)
            for i, (model, optimizer) in enumerate(zip(population, optimizers)):
                # fitness_model = get_loss(model, self.valloader, self.device, self.criterion, self.lambda_reg)
                update_model, epoch_time = self.DE_update(population, model, best_individual, self.F)

                updated_population.append(update_model)

                train_loss, train_acc = acc_loss(update_model, self.trainloader, self.device, self.criterion)
                loss.append(train_loss)
                test_loss, test_acc = acc_loss(update_model, self.testloader, self.device, self.criterion)
                valid_loss, valid_acc = acc_loss(update_model, self.valloader, self.device, self.criterion)
                weight = self.weight_l1(update_model)

                train_losses.append(train_loss)
                test_losses.append(test_loss)
                valid_losses.append(valid_loss)
                train_accs.append(train_acc)
                test_accs.append(test_acc)
                valid_accs.append(valid_acc)
                epoch_times.append(epoch_time)
                Weight_individual.append(int(weight))
                sparsity = self.weight_l0(model, prune_threshold)
                Sparsity_weight_individual.append(sparsity)

                print(
                    f"Individual {i + 1}: Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, "
                    f"Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.2f}%, "
                    f"Valid Loss: {valid_loss:.4f}, Valid Acc: {valid_acc:.2f}%, "
                    f"Weight: {weight:.4f}, Time: {epoch_time:.2f}s")

            train_losses_all.append(list(train_losses))
            test_losses_all.append(list(test_losses))
            valid_losses_all.append(list(valid_losses))
            train_accs_all.append(list(train_accs))
            test_accs_all.append(list(test_accs))
            valid_accs_all.append(list(valid_accs))
            epoch_times_all.append(list(epoch_times))
            Weight_individual_all.append(list(Weight_individual))
            Sparsity_weight_all.append(list(Sparsity_weight))

            best_individual, Fitness, Fitness_sort = self.fitness_sort(updated_population + population)
            population, Fitness = self.select(Fitness_sort)
            # individual_labels, sorted_indices = self.sort_population(Fitness)
            end_time = time.time()
            epoch_time_all = end_time - begin_time
            self.t += 1


            # 选择最优个体
            print("min fitness in validation data: {} ".format(np.min(Fitness)))
            test_loss_best, test_acc_best = acc_loss(best_individual, self.testloader, self.device, self.criterion)
            train_loss_best, train_acc_best = acc_loss(best_individual, self.trainloader, self.device, self.criterion)
            valid_loss_best, valid_acc_best = acc_loss(best_individual, self.valloader, self.device, self.criterion)
            Weight = self.weight_l1(best_individual)

            sparsity_best = self.weight_l0(best_individual, prune_threshold)

            print(
                f"Best Individual: Train Loss: {train_loss_best:.4f}, Train Acc: {train_acc_best:.2f}%, "
                f"Test Loss: {test_loss_best:.4f}, Test Acc: {test_acc_best:.2f}%, "
                f"Valid Loss: {valid_loss_best:.4f}, Valid Acc: {valid_acc_best:.2f}%, "
                f"Weight: {Weight:.4f},Weight sparsity: {sparsity_best:.4f},time_all:{epoch_time_all:.2f}s")

            # 存储每一代中最优个体的精度和损失

            Train_cost_list.append(train_loss_best)
            Test_cost_list.append(test_loss_best)
            Valid_cost_list.append(valid_loss_best)
            Train_Accuracy_list.append(train_acc_best)
            Test_Accuracy_list.append(test_acc_best)
            Valid_Accuracy_list.append(valid_acc_best)
            times.append(epoch_time_all)
            Weight_epoch.append(int(Weight))
            Sparsity_weight.append(sparsity_best)


        return train_losses_all, test_losses_all, valid_losses_all, train_accs_all, test_accs_all, valid_accs_all, \
               epoch_times_all, Weight_individual_all, Sparsity_weight_all,\
               Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, \
               Valid_Accuracy_list, times, Weight_epoch, Sparsity_weight


