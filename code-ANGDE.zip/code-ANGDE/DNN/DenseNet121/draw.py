import matplotlib.pyplot as plt
import os

def draw_results(list, title, label, figure_save_path):
    plt.figure(figsize=(8, 6))
    x0 = range(0, len(list[0]))
    x1 = range(0, len(list[1]))
    x2 = range(0, len(list[2]))
    x3 = range(0, len(list[3]))
    x4 = range(0, len(list[4]))
    x5 = range(0, len(list[5]))
    y0 = list[0]
    y1 = list[1]
    y2 = list[2]
    y3 = list[3]
    y4 = list[4]
    y5 = list[5]

    plt.plot(x0, y0, color='salmon', marker='.', linestyle='-', label='SGD')
    plt.plot(x1, y1, color='royalblue', marker='.', linestyle='-', label='ADAM')
    plt.plot(x2, y2, color='darkgreen', marker='.', linestyle='-', label='DE')
    plt.plot(x3, y3, color='lightpink', marker='.', linestyle='-', label='ESGD')
    plt.plot(x4, y4, color='cyan', marker='.', linestyle='-', label='NGDE')
    plt.plot(x5, y5, color='mediumorchid', marker='.', linestyle='-', label='INGDE')

    plt.tick_params(labelsize=18)
    plt.xlabel('Epoches', fontsize=20)
    plt.ylabel(str(label), fontsize=20)
    plt.legend(loc='best', fontsize=18)
    # 指定图片保存路径
    fig_name = title
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)  # 如果不存在目录figure_save_path，则创建
    plt.savefig(os.path.join(figure_save_path, fig_name), dpi=300, bbox_inches='tight')  # 分别命名图片
    plt.close()


def draw_population(list_all, title, label, num_epochs, population_size, figure_save_path):
    # 个体测试正确率折线图
    plt.figure(figsize=(10, 6))
    epochs = range(1, num_epochs + 1)

    for i in range(population_size):
        new_list = [sublist[i] for sublist in list_all]
        # print("Individual ", i," :",  new_list)
        plt.plot(epochs, new_list, label=f"Individual {i + 1}")
    # # 绘制图像
    # epochs = range(1, num_epochs + 1)
    #
    # for i in range(population_size):
    #     plt.plot(epochs, list_all[i], label=f"Individual {i + 1}")
    # plt.plot(epochs, best_Adam_test_accs, label="Adam")
    # plt.xlabel("Epoch")
    # plt.ylabel("Testing Accuracy (%)")
    # plt.title("Testing Accuracy")
    # plt.legend()
    # plt.grid(True)
    # plt.tight_layout()
    # plt.show()
    plt.tick_params(labelsize=18)
    plt.xlabel('Epoches', fontsize=20)
    plt.ylabel(str(label), fontsize=20)
    plt.legend(loc='best', fontsize=18)
    # 指定图片保存路径
    fig_name = title
    if not os.path.exists(figure_save_path):
        os.makedirs(figure_save_path)  # 如果不存在目录figure_save_path，则创建
    plt.savefig(os.path.join(figure_save_path, fig_name), dpi=300, bbox_inches='tight')  # 分别命名图片
    plt.close()

def draw_train_acc_population(num_epochs, population_size, all_individual_train_accs, best_Adam_train_accs):
    # 绘制图像
    epochs = range(1, num_epochs + 1)

    # 个体训练正确率折线图
    plt.figure(figsize=(10, 6))
    for i in range(population_size):
        plt.plot(epochs, all_individual_train_accs[i], label=f"Individual {i + 1}")
    plt.plot(epochs, best_Adam_train_accs, label="Adam")
    plt.xlabel("Epoch")
    plt.ylabel("Training Accuracy (%)")
    plt.title("Training Accuracy")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

def draw_test_acc_population(num_epochs, population_size, all_individual_test_accs, best_Adam_test_accs):
    # 绘制图像
    epochs = range(1, num_epochs + 1)
    # 个体测试正确率折线图
    plt.figure(figsize=(10, 6))
    for i in range(population_size):
        plt.plot(epochs, all_individual_test_accs[i], label=f"Individual {i + 1}")
    plt.plot(epochs, best_Adam_test_accs, label="Adam")
    plt.xlabel("Epoch")
    plt.ylabel("Testing Accuracy (%)")
    plt.title("Testing Accuracy")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()



def draw_train_acc(num_epochs, best_individual_train_accs, best_Adam_train_accs, best_sgd_train_accs,
                   best_rmsprop_train_accs):
    # 绘制图像
    epochs = range(1, num_epochs + 1)
    # 训练正确率折线图
    plt.figure(figsize=(10, 6))
    plt.plot(epochs, best_individual_train_accs, label="best_individual")
    plt.plot(epochs, best_Adam_train_accs, label="Adam")
    plt.plot(epochs, best_sgd_train_accs, label="SGD")
    plt.plot(epochs, best_rmsprop_train_accs, label="RMSprop")
    plt.xlabel("Epoch")
    plt.ylabel("Training Accuracy (%)")
    plt.title("Training Accuracy")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

def draw_test_acc(num_epochs, best_individual_test_accs, best_Adam_test_accs,
                   best_sgd_test_accs, best_rmsprop_test_accs):
    # 绘制图像
    epochs = range(1, num_epochs + 1)
    # 测试正确率折线图
    plt.figure(figsize=(10, 6))
    plt.plot(epochs, best_individual_test_accs, label="best_individual")
    plt.plot(epochs, best_Adam_test_accs, label="Adam")
    plt.plot(epochs, best_sgd_test_accs, label="SGD")
    plt.plot(epochs, best_rmsprop_test_accs, label="RMSprop")
    plt.xlabel("Epoch")
    plt.ylabel("Testing Accuracy (%)")
    plt.title("Testing Accuracy")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


# # 平均一个epoch所需时间柱状图
# avg_individual_epoch_times = sum([sum(times) / num_epochs for times in epoch_times])
# avg_epoch_times_ratio = avg_individual_epoch_times/(sum(adam_epoch_times) / num_epochs)
# print(avg_epoch_times_ratio)

# # 训练正确率折线图
# plt.figure(figsize=(10, 6))
# for i in range(num_individuals):
#     plt.plot(epochs, train_accs[i], label=f"Individual {i+1}")
# plt.plot(epochs, adam_train_accs, label="Adam")
# plt.xlabel("Epoch")
# plt.ylabel("Training Accuracy (%)")
# plt.title("Training Accuracy")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载1.png", format="png", dpi=300)
#
# # 测试正确率折线图
# plt.figure(figsize=(10, 6))
# for i in range(num_individuals):
#     plt.plot(epochs, test_accs[i], label=f"Individual {i+1}")
# plt.plot(epochs, adam_test_accs, label="Adam")
# plt.xlabel("Epoch")
# plt.ylabel("Testing Accuracy (%)")
# plt.title("Testing Accuracy")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载2.png", format="png", dpi=300)
#
# # 训练损失值折线图
# plt.figure(figsize=(10, 6))
# for i in range(num_individuals):
#     plt.plot(epochs, train_losses[i], label=f"Individual {i+1}")
# plt.plot(epochs, adam_train_losses, label="Adam")
# plt.xlabel("Epoch")
# plt.ylabel("Training Loss")
# plt.title("Training Loss")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载3.png", format="png", dpi=300)
#
# # 测试损失值折线图
# plt.figure(figsize=(10, 6))
# for i in range(num_individuals):
#     plt.plot(epochs, test_losses[i], label=f"Individual {i+1}")
# plt.plot(epochs, adam_test_losses, label="Adam")
# plt.xlabel("Epoch")
# plt.ylabel("Testing Loss")
# plt.title("Testing Loss")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载4.png", format="png", dpi=300)
#
# # 训练正确率折线图
# plt.figure(figsize=(10, 6))
# plt.plot(epochs, best_train_accs, label="Best-individual")
# plt.plot(epochs, sgd_train_accs, label="SGD")
# plt.plot(epochs, adam_train_accs, label="Adam")
# plt.plot(epochs, rmsprop_train_accs, label="RMSprop")
# plt.xlabel("Epoch")
# plt.ylabel("Training Accuracy (%)")
# plt.title("Training Accuracy")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载5.png", format="png", dpi=300)
#
# # 测试正确率折线图
# plt.figure(figsize=(10, 6))
# plt.plot(epochs, best_test_accs, label="Best-individual")
# plt.plot(epochs, sgd_test_accs, label="SGD")
# plt.plot(epochs, adam_test_accs, label="Adam")
# plt.plot(epochs, rmsprop_test_accs, label="RMSprop")
# plt.xlabel("Epoch")
# plt.ylabel("Testing Accuracy (%)")
# plt.title("Testing Accuracy")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载6.png", format="png", dpi=300)
#
# # 训练损失值折线图
# plt.figure(figsize=(10, 6))
# plt.plot(epochs, best_train_losses, label="Best-individual")
# plt.plot(epochs, sgd_train_losses, label="SGD")
# plt.plot(epochs, adam_train_losses, label="Adam")
# plt.plot(epochs, rmsprop_train_losses, label="RMSprop")
# plt.xlabel("Epoch")
# plt.ylabel("Training Loss")
# plt.title("Training Loss")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载7.png", format="png", dpi=300)
#
# # 测试损失值折线图
# plt.figure(figsize=(10, 6))
# plt.plot(epochs, best_test_losses, label="Best-individual")
# plt.plot(epochs, sgd_test_losses, label="SGD")
# plt.plot(epochs, adam_test_losses, label="Adam")
# plt.plot(epochs, rmsprop_test_losses, label="RMSprop")
# plt.xlabel("Epoch")
# plt.ylabel("Testing Loss")
# plt.title("Testing Loss")
# plt.legend()
# plt.grid(True)
# plt.tight_layout()
# plt.show()
# plt.savefig("C:\\Users\\HH\\Desktop\\下载8.png", format="png", dpi=300)