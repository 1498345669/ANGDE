from data_load import choose_dataset
import torch.optim as optim
from CNN import *
from AINGDE import *
from SGD import SGD
from DE import DE
from ESGD import ESGD
from NGDE import NGDE
from Adam import ADAM
from draw import *
from tocsv import *
import time
from GD import *
from get_fitness import *
import pandas as pd

import torch.nn as nn

# def initialize_weights(model):
#     for m in model.modules():
#         if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
#             nn.init.kaiming_normal_(m.weight)
#             if m.bias is not None:
#                 nn.init.constant_(m.bias, 0)
#
# def initial_population(n, population_size, device):
#     population = []
#     for _ in range(population_size):
#         model = CustomVGG16(num_classes=n).to(device)
#         initialize_weights(model)
#         population.append(model)
#     return population

def initialize_weights(model):
    for m in model.modules():
        if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)


def initial_population(n, population_size, device):
    population = []
    for _ in range(population_size):
        model = DenseNet121(n).to(device)
        initialize_weights(model)
        population.append(model)
    return population



def run_method(dataname, batch_size, device, population_size, lr_ingde, lr_sgd, lr_adam, num_epochs, fitness_p, fitness_p_ngde, F, niche_size, lambda_reg,
               F_min, F_max, gd_epochs, evo_epochs, distance_factor_max, distance_factor_min, figure_save_path):
    # 导入数据
    train_dataset, val_dataset, test_dataset, trainloader, valloader, testloader, n = choose_dataset(dataname, batch_size)  # CIFAR10,CIFAR100,MNIST,FashionMNIST,STL10,SVHN
    print('n:', n)

    print(f"Train dataset size: {len(train_dataset)}")
    print(f"Validation dataset size: {len(val_dataset)}")
    print(f"Test dataset size: {len(test_dataset)}")
    print(f"Number of classes: {n}")

    # CIFAR10_resnet18,CIFAR100_resnet18,MNIST_resnet18,CIFAR100_VGG16
    # CIFAR10_MobileNetV2,CIFAR10_DenseNet121

    # 定义损失函数和优化器
    criterion = nn.CrossEntropyLoss()
    figure_save_path_results = figure_save_path
    torch.manual_seed(0)

    # ==================INGDE======================
    print("======== Running INGDE ========")
    # 初始化种群
    start = time.time()

    population = initial_population(n, population_size, device)  # [VGG16(n).to(device) for _ in range(population_size)]
    optimizers = [optim.Adam(model.parameters(), lr=lr_ingde, betas=(0.9, 0.999),  weight_decay=1e-4, amsgrad=True) for  model in population]
    torch.cuda.empty_cache()

    ingde = ANGDE(trainloader, testloader, valloader, criterion,lambda_reg,
                  population_size, F_min, F_max, distance_factor_max, distance_factor_min, fitness_p, num_epochs)
    train_losses_ingde, test_losses_ingde, valid_losses_ingde, \
        train_accs_ingde, test_accs_ingde, valid_accs_ingde, epoch_times_ingde, weight_ingde, Sparsity_weight_all_ingde, \
        Train_Accuracy_list_ingde, Train_cost_list_ingde, Test_Accuracy_list_ingde, \
        Test_cost_list_ingde, Valid_cost_list_ingde, Valid_Accuracy_list_ingde, \
        times_ingde, weight_all_ingde, num_niche_ingde, Sparsity_weight_ingde = ingde.INGDE(optimizers, population, figure_save_path, n)
    end = time.time()
    time_ingde = (end - start) / 60

    # ==================Adam======================
    # 初始化种群
    print("======== Running Adam ========")
    start = time.time()
    population = initial_population(n, population_size, device)
    optimizers = [
        optim.Adam(model.parameters(), lr=lr_adam, betas=(0.9, 0.999),  weight_decay=1e-4, amsgrad=True) for
        model in population]
    torch.cuda.empty_cache()
    Adam = ADAM(trainloader, testloader, valloader, criterion,
                population_size, num_epochs)
    adam_train_losses_all, adam_test_losses_all, adam_valid_losses_all, adam_train_accs_all, \
        adam_test_accs_all, adam_valid_accs_all, adam_epoch_times_all, adam_Weight_individual_all, \
        adam_Sparsity_weight_all, adam_Train_Accuracy_list, adam_Train_cost_list, \
        adam_Test_Accuracy_list, adam_Test_cost_list, adam_Valid_cost_list, \
        adam_Valid_Accuracy_list, adam_times, adam_Weight_epoch, adam_Sparsity_weight = Adam.adam(optimizers,
                                                                                                  population, figure_save_path)
    end = time.time()
    time_adam = (end - start) / 60

    # ==================SGD======================
    print("======== Running SGD ========")
    start = time.time()
    population = initial_population(n, population_size, device)
    optimizers = [optim.SGD(model.parameters(), lr=lr_sgd, weight_decay=1e-4) for model in population]
    torch.cuda.empty_cache()
    Sgd = SGD(trainloader, testloader, valloader, criterion, population_size, num_epochs)

    sgd_train_losses_all, sgd_test_losses_all, sgd_valid_losses_all, sgd_train_accs_all, sgd_test_accs_all, \
        sgd_valid_accs_all, sgd_epoch_times_all, sgd_Weight_individual_all, sgd_Sparsity_weight_all, \
        sgd_Train_Accuracy_list, sgd_Train_cost_list, sgd_Test_Accuracy_list, sgd_Test_cost_list, \
        sgd_Valid_cost_list, sgd_Valid_Accuracy_list, sgd_times, sgd_Weight_epoch, sgd_Sparsity_weight = Sgd.sgd(
        optimizers, population, figure_save_path)
    end = time.time()
    time_sgd = (end - start) / 60

    # ==================NGDE======================
    print("======== Running NGDE ========")
    # 初始化种群
    start = time.time()
    population = initial_population(n, population_size, device)  # [VGG16(n).to(device) for _ in range(population_size)]
    # optimizers = [optim.SGD(model.parameters(), lr=lr_sgd) for model in population]
    optimizers = [optim.SGD(model.parameters(), lr=lr_sgd, weight_decay=1e-4) for model in population]
    # optimizers = [
        # optim.Adam(model.parameters(), lr=lr_adam, betas=(0.9, 0.999), weight_decay=1e-4, amsgrad=True) for
        # model in population]
    torch.cuda.empty_cache()
    ngde = NGDE(trainloader, testloader, valloader, criterion,
                population_size, F, fitness_p_ngde, niche_size, num_epochs)
    train_losses_ngde, test_losses_ngde, valid_losses_ngde, \
        train_accs_ngde, test_accs_ngde, valid_accs_ngde, epoch_times_ngde, weight_ngde, Sparsity_weight_all_ngde, \
        Train_Accuracy_list_ngde, Train_cost_list_ngde, Test_Accuracy_list_ngde, \
        Test_cost_list_ngde, Valid_cost_list_ngde, Valid_Accuracy_list_ngde, \
        times_ngde, weight_all_ngde, num_niche_ngde, Sparsity_weight_epoch_ngde = ngde.NGDE(optimizers, population, figure_save_path)
    end = time.time()
    time_ngde = (end - start) / 60

    # ==================ESGD======================
    print("======== Running ESGD ========")
    start = time.time()
    population = initial_population(n, population_size, device)
    # optimizers = [optim.SGD(model.parameters(), lr=lr_sgd) for model in population]
    optimizers = [
        optim.Adam(model.parameters(), lr=lr_adam, betas=(0.9, 0.999),  weight_decay=1e-4, amsgrad=True) for
        model in population]
    torch.cuda.empty_cache()
    esgd = ESGD(trainloader, testloader, valloader, criterion, gd_epochs, evo_epochs,
                population_size, F, num_epochs)
    train_losses_esgd, test_losses_esgd, valid_losses_esgd, \
        train_accs_esgd, test_accs_esgd, valid_accs_esgd, epoch_times_esgd, weight_esgd, Sparsity_weight_all_esgd, \
        Train_Accuracy_list_esgd, Train_cost_list_esgd, Test_Accuracy_list_esgd, \
        Test_cost_list_esgd, Valid_cost_list_esgd, Valid_Accuracy_list_esgd, \
        times_esgd, weight_all_esgd, Sparsity_weight_esgd = esgd.ESGD(optimizers, population, figure_save_path)
    end = time.time()
    time_esgd = (end - start) / 60

    # ==================DE======================
    print("======== Running DE ========")
    start = time.time()
    population = initial_population(n, population_size, device)
    # optimizers = [optim.SGD(model.parameters(), lr=lr_sgd) for model in population]
    optimizers = [
        optim.Adam(model.parameters(), lr=lr_adam, betas=(0.9, 0.999), weight_decay=1e-4, amsgrad=True) for
        model in population]
    torch.cuda.empty_cache()
    de = DE(trainloader, testloader, valloader, criterion,
            population_size, F, num_epochs)
    train_losses_de, test_losses_de, valid_losses_de, \
        train_accs_de, test_accs_de, valid_accs_de, epoch_times_de, weight_de, Sparsity_weight_all_de, \
        Train_Accuracy_list_de, Train_cost_list_de, Test_Accuracy_list_de, \
        Test_cost_list_de, Valid_cost_list_de, Valid_Accuracy_list_de, \
        times_de, weight_all_de, Sparsity_weight_de = de.DE(optimizers, population, figure_save_path)
    end = time.time()
    time_de = (end - start) / 60

    # 定义对比优化器
    ###=======================================draw============================

    Train_Accuracy_list = [sgd_Train_Accuracy_list, adam_Train_Accuracy_list, Train_Accuracy_list_de, Train_Accuracy_list_esgd, Train_Accuracy_list_ngde, Train_Accuracy_list_ingde]
    draw_results(Train_Accuracy_list, dataname + "-Train Accuracy", "Train Accuracy", figure_save_path_results)

    Train_cost_list = [sgd_Train_cost_list, adam_Train_cost_list, Train_cost_list_de, Train_cost_list_esgd, Train_cost_list_ngde, Train_cost_list_ingde]
    draw_results(Train_cost_list, dataname + "-Train cost", "Train cost", figure_save_path_results)

    Test_Accuracy_list = [sgd_Test_Accuracy_list, adam_Test_Accuracy_list, Test_Accuracy_list_de, Test_Accuracy_list_esgd, Test_Accuracy_list_ngde, Test_Accuracy_list_ingde]
    draw_results(Test_Accuracy_list, dataname + "-Test Accuracy", "Test Accuracy", figure_save_path_results)

    Test_cost_list = [sgd_Test_cost_list, adam_Test_cost_list, Test_cost_list_de, Test_cost_list_esgd, Test_cost_list_ngde, Test_cost_list_ingde]
    draw_results(Test_cost_list, dataname + "-Test cost", "Test cost", figure_save_path_results)

    Valid_Accuracy_list = [sgd_Valid_Accuracy_list, adam_Valid_Accuracy_list, Valid_Accuracy_list_de, Valid_Accuracy_list_esgd, Valid_Accuracy_list_ngde, Valid_Accuracy_list_ingde]
    draw_results(Valid_Accuracy_list, dataname + "-Valid Accuracy", "Valid Accuracy", figure_save_path_results)

    Valid_cost_list = [sgd_Valid_cost_list, adam_Valid_cost_list, Valid_cost_list_de, Valid_cost_list_esgd, Valid_cost_list_ngde, Valid_cost_list_ingde]
    draw_results(Valid_cost_list, dataname + "-Valid cost", "Valid cost", figure_save_path_results)

    Weight_list = [sgd_Weight_epoch, adam_Weight_epoch, weight_all_de, weight_all_esgd, weight_all_ngde, weight_all_ingde]
    SparsityWeight_list = [sgd_Sparsity_weight, adam_Sparsity_weight, Sparsity_weight_de, Sparsity_weight_esgd,
                   Sparsity_weight_epoch_ngde, Sparsity_weight_ingde]
    print("weight list:", Weight_list)

    print("SparsityWeight_list:", SparsityWeight_list)

    draw_results(Weight_list, dataname + "-Weight", "Weight", figure_save_path_results)
    draw_results(SparsityWeight_list, dataname + "-Sparsity_Weight", "Sparsity_Weight", figure_save_path_results)

    print(test_losses_ingde)
    # 计算每一代所有个体损失的均值
    average_losses_per_generation = [sum(losses) / len(losses) for losses in zip(*test_losses_ingde)]
    print(average_losses_per_generation)

    # ==================================time====================
    # run_time = [time_sgd, adam_epoch_times_all, epoch_times_de, epoch_times_esgd, epoch_times_ngde, epoch_times_ingde]
    run_time = [time_sgd, time_adam, time_de, time_esgd, time_ngde, time_ingde]

    run_onetime = [time_sgd, adam_epoch_times_all, epoch_times_de, epoch_times_esgd, epoch_times_ngde,
                   epoch_times_ingde]
    # ======================================================
    tocsv(run_time, run_onetime, figure_save_path, dataname, Train_Accuracy_list, Train_cost_list,
          Test_Accuracy_list, Test_cost_list, Valid_Accuracy_list, Valid_cost_list, Weight_list, SparsityWeight_list)

    print("test_loss_ingde:", test_losses_ingde)
    print("train_loss_ingde:", train_losses_ingde)

    print("weight_indge", weight_ingde)
    print("weight_All_indge", weight_all_ingde)

    # print(train_losses_ingde)

    pd.DataFrame(num_niche_ingde).to_excel(figure_save_path + "/num_niche-" + dataname + ".xlsx")

    draw_population(test_losses_ingde, dataname + "-all test cost", "Test cost", num_epochs, population_size,
                    figure_save_path_results)
    pd.DataFrame(test_losses_ingde).to_excel(figure_save_path + "/test cost-" + dataname + ".xlsx")

    draw_population(train_losses_ingde, dataname + "-all train cost", "Train cost", num_epochs, population_size,
                    figure_save_path_results)
    pd.DataFrame(train_losses_ingde).to_excel(figure_save_path + "/train cost-" + dataname + ".xlsx")

    draw_population(valid_losses_ingde, dataname + "-all valid cost", "Valid cost", num_epochs, population_size,
                    figure_save_path_results)
    pd.DataFrame(valid_losses_ingde).to_excel(figure_save_path + "/valid cost-" + dataname + ".xlsx")

    draw_population(test_accs_ingde, dataname + "-all test acc", "Test ACC", num_epochs, population_size,
                    figure_save_path_results)
    pd.DataFrame(test_accs_ingde).to_excel(figure_save_path + "/test acc-" + dataname + ".xlsx")

    draw_population(train_accs_ingde, dataname + "-all train acc", "Train ACC", num_epochs, population_size,
                    figure_save_path_results)
    pd.DataFrame(train_accs_ingde).to_excel(figure_save_path + "/train acc-" + dataname + ".xlsx")

    draw_population(valid_accs_ingde, dataname + "-all valid acc", "Valid ACC", num_epochs, population_size,
                    figure_save_path_results)
    pd.DataFrame(valid_accs_ingde).to_excel(figure_save_path + "/valid acc-" + dataname + ".xlsx")

    # draw_population(weight_ingde, dataname + "-all weight", "Weight", num_epochs, population_size,
    #                 figure_save_path_results)
    pd.DataFrame(weight_ingde).to_excel(figure_save_path + "/all weight" + dataname + ".xlsx")

    # draw_population(Sparsity_weight_all_ingde, dataname + "-all weight", "Sparsity Weight", num_epochs, population_size,
    #                 figure_save_path_results)
    pd.DataFrame(Sparsity_weight_all_ingde).to_excel(figure_save_path + "/all Sparsity weight" + dataname + ".xlsx")

#
    # draw_train_acc_population(num_epochs, population_size, all_individual_train_accs, best_Adam_train_accs)
    # draw_test_acc_population(num_epochs, population_size, all_individual_test_accs, best_Adam_test_accs)
    # draw_train_acc(num_epochs, best_individual_train_accs, best_Adam_train_accs, best_sgd_train_accs,
    #                best_rmsprop_train_accs)
    # draw_test_acc(num_epochs, best_individual_test_accs, best_Adam_test_accs,
    #               best_sgd_test_accs, best_rmsprop_test_accs)


    # adam_train_losses, adam_test_losses, adam_train_accs, adam_test_accs, adam_epoch_times = [], [], [], [], []
    #
    # for epoch in range(num_epochs):
    #     print(f"Epoch [{epoch + 1}/{num_epochs}]")
    #
    #     adam_train_loss, adam_train_acc, adam_epoch_time = train(adam_model, adam_optimizer, trainloader,
    #                                                              criterion)
    #     adam_test_loss, adam_test_acc = acc_loss(adam_model, testloader, device, criterion)
    #     adam_train_losses.append(adam_train_loss)
    #     adam_test_losses.append(adam_test_loss)
    #     adam_train_accs.append(adam_train_acc)
    #     adam_test_accs.append(adam_test_acc)
    #     adam_epoch_times.append(adam_epoch_time)
    #     print(
    #         f"Adam: Train Loss: {adam_train_loss:.4f}, Train Acc: {adam_train_acc:.2f}%, Test Loss: {adam_test_loss:.4f}, Test Acc: {adam_test_acc:.2f}%, Time: {adam_epoch_time:.2f}s")

    # # ==================RMSprop======================
    # rmsprop_model = VGG16(n).to(device)
    # rmsprop_optimizer = optim.RMSprop(rmsprop_model.parameters())
    # rmsprop_train_losses, rmsprop_test_losses, rmsprop_train_accs, rmsprop_test_accs, rmsprop_epoch_times = [], [], [], [], []
    # for epoch in range(num_epochs):
    #     print(f"Epoch [{epoch + 1}/{num_epochs}]")
    #     rmsprop_train_loss, rmsprop_train_acc, rmsprop_epoch_time = train(rmsprop_model, rmsprop_optimizer, trainloader,
    #                                                                       criterion)
    #     rmsprop_test_loss, rmsprop_test_acc = acc_loss(rmsprop_model, testloader, device, criterion)
    #     rmsprop_train_losses.append(rmsprop_train_loss)
    #     rmsprop_test_losses.append(rmsprop_test_loss)
    #     rmsprop_train_accs.append(rmsprop_train_acc)
    #     rmsprop_test_accs.append(rmsprop_test_acc)
    #     rmsprop_epoch_times.append(rmsprop_epoch_time)
    #     print(f"RMSprop: Train Loss: {rmsprop_train_loss: .4f}, TrainAcc: {rmsprop_train_acc: .2f} %, TestLoss: {rmsprop_test_loss: .4f}, TestAcc: {rmsprop_test_acc: .2f} %, Time: {rmsprop_epoch_time: .2f}s")
    #
    # # ======================choose best=============================
    # def get_best_cumulative_values(values):
    #     best_values = [values[0]]
    #     for i in range(1, len(values)):
    #         if values[i] > best_values[-1]:
    #             best_values.append(values[i])
    #         else:
    #             best_values.append(best_values[-1])
    #     return best_values
    #
    # # 获取最佳训练和测试损失及准确率
    # best_train_losses_ingde = [max(col) for col in zip(*train_losses_ingde)]
    # best_train_accs_ingde = [max(col) for col in zip(*train_accs_ingde)]
    # best_test_losses_ingde = [max(col) for col in zip(*test_losses_ingde)]
    # best_test_accs_ingde = [max(col) for col in zip(*test_accs_ingde)]
    #
    #
    # # 获取最佳的累积训练和测试准确率
    # best_individual_train_accs = get_best_cumulative_values(best_train_accs)
    # best_individual_test_accs = get_best_cumulative_values(best_test_accs)
    # best_Adam_train_accs = get_best_cumulative_values(adam_train_accs)
    # best_Adam_test_accs = get_best_cumulative_values(adam_test_accs)
    # best_sgd_train_accs = get_best_cumulative_values(sgd_train_accs)
    # best_sgd_test_accs = get_best_cumulative_values(sgd_test_accs)
    # best_rmsprop_train_accs = get_best_cumulative_values(rmsprop_train_accs)
    # best_rmsprop_test_accs = get_best_cumulative_values(rmsprop_test_accs)
    #
    # # 处理所有个体的训练和测试准确率
    # all_individual_train_accs = [[] for _ in range(population_size)]
    # all_individual_test_accs = [[] for _ in range(population_size)]
    #
    # for i in range(population_size):
    #     all_individual_train_accs[i] = get_best_cumulative_values(train_accs[i])
    #     all_individual_test_accs[i] = get_best_cumulative_values(test_accs[i])
    #
    #
    # ###=======================================draw============================
    # # 将不同的数据分别存储在不同的Excel文件中
    #
    # # 存储最佳训练和测试损失及准确率
    # data_best = {
    #     "best_train_losses": best_train_losses,
    #     "best_train_accs": best_train_accs,
    #     "best_test_losses": best_test_losses,
    #     "best_test_accs": best_test_accs
    # }
    # df_best = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in data_best.items()]))
    # df_best.to_excel("best_results.xlsx", index=False)
    #
    # # 存储最佳的累积训练和测试准确率
    # data_cumulative = {
    #     "best_individual_train_accs": best_individual_train_accs,
    #     "best_individual_test_accs": best_individual_test_accs,
    #     "best_Adam_train_accs": best_Adam_train_accs,
    #     "best_Adam_test_accs": best_Adam_test_accs,
    #     "best_sgd_train_accs": best_sgd_train_accs,
    #     "best_sgd_test_accs": best_sgd_test_accs,
    #     "best_rmsprop_train_accs": best_rmsprop_train_accs,
    #     "best_rmsprop_test_accs": best_rmsprop_test_accs
    # }
    # df_cumulative = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in data_cumulative.items()]))
    # df_cumulative.to_excel("cumulative_results.xlsx", index=False)
    #
    # # 存储所有个体的训练和测试准确率
    # for i in range(population_size):
    #     data_individual = {
    #         f"individual_{i}_train_accs": all_individual_train_accs[i],
    #         f"individual_{i}_test_accs": all_individual_test_accs[i]
    #     }
    #     df_individual = pd.DataFrame(data_individual)
    #     df_individual.to_excel(f"individual_{i}_results.xlsx", index=False)

    # best_train_losses = [max(col) for col in zip(*train_losses)]
    # best_train_accs = [max(col) for col in zip(*train_accs)]
    # best_test_losses = [max(col) for col in zip(*test_losses)]
    # best_test_accs = [max(col) for col in zip(*test_accs)]
    #
    # #
    # best_individual_train_accs = [best_train_accs[0]]
    # for i in range(1, len(best_train_accs)):
    #     if best_train_accs[i] > best_individual_train_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_individual_train_accs.append(best_train_accs[i])
    #     else:
    #         best_individual_train_accs.append(best_individual_train_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中
    #
    # best_individual_test_accs = [best_test_accs[0]]
    # for i in range(1, len(best_test_accs)):
    #     if best_test_accs[i] > best_individual_test_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_individual_test_accs.append(best_test_accs[i])
    #     else:
    #         best_individual_test_accs.append(best_individual_test_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中
    #
    # #
    # best_Adam_test_accs = [adam_test_accs[0]]
    # for i in range(1, len(adam_test_accs)):
    #     if adam_test_accs[i] > best_Adam_test_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_Adam_test_accs.append(adam_test_accs[i])
    #     else:
    #         best_Adam_test_accs.append(best_Adam_test_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中
    # #
    # best_Adam_train_accs = [adam_train_accs[0]]
    # for i in range(1, len(adam_train_accs)):
    #     if adam_train_accs[i] > best_Adam_train_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_Adam_train_accs.append(adam_train_accs[i])
    #     else:
    #         best_Adam_train_accs.append(best_Adam_train_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中
    #
    # #
    # best_sgd_train_accs = [sgd_train_accs[0]]
    # for i in range(1, len(sgd_train_accs)):
    #     if sgd_train_accs[i] > best_sgd_train_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_sgd_train_accs.append(sgd_train_accs[i])
    #     else:
    #         best_sgd_train_accs.append(best_sgd_train_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中
    #
    # #
    # best_sgd_test_accs = [sgd_test_accs[0]]
    # for i in range(1, len(sgd_test_accs)):
    #     if sgd_test_accs[i] > best_sgd_test_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_sgd_test_accs.append(sgd_test_accs[i])
    #     else:
    #         best_sgd_test_accs.append(best_sgd_test_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中
    #
    # #
    # best_rmsprop_train_accs = [rmsprop_train_accs[0]]
    # for i in range(1, len(rmsprop_train_accs)):
    #     if rmsprop_train_accs[i] > best_rmsprop_train_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_rmsprop_train_accs.append(rmsprop_train_accs[i])
    #     else:
    #         best_rmsprop_train_accs.append(best_rmsprop_train_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中
    #
    # #
    # best_rmsprop_test_accs = [rmsprop_test_accs[0]]
    # for i in range(1, len(rmsprop_test_accs)):
    #     if rmsprop_test_accs[i] > best_rmsprop_test_accs[-1]:  # 如果列表a的当前元素大于列表b的最后一个元素
    #         best_rmsprop_test_accs.append(rmsprop_test_accs[i])
    #     else:
    #         best_rmsprop_test_accs.append(best_rmsprop_test_accs[-1])  # 否则，将列表b的最后一个元素添加到列表b中


    # all_individual_train_accs = [[] for _ in range(population_size)]
    # all_individual_test_accs = [[] for _ in range(population_size)]
    # for i in range(population_size):
    #     all_individual_train_accs[i].append(train_accs[i][0])
    #     all_individual_test_accs[i].append(test_accs[i][0])
    #
    #     for j in range(1, len(test_accs[i])):
    #         if train_accs[i][j] > all_individual_train_accs[i][-1]:
    #             all_individual_train_accs[i].append(train_accs[i][j])
    #         else:
    #             all_individual_train_accs[i].append(all_individual_train_accs[i][-1])
    #
    #         if test_accs[i][j] > all_individual_test_accs[i][-1]:
    #             all_individual_test_accs[i].append(test_accs[i][j])
    #         else:
    #             all_individual_test_accs[i].append(all_individual_test_accs[i][-1])


