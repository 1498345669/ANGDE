import copy
import random
from get_fitness import *
import torch
import numpy as np
from checkpoint import save_checkpoint


class SGD():
    def __init__(self, trainloader, testloader, valloader, criterion,
                 population_size,  num_epoch):
        # self.optimizer = optimizer

        self.trainloader = trainloader
        self.testloader = testloader
        self.valloader = valloader
        self.criterion = criterion
        self.population_size = population_size
        self.num_epoch = num_epoch
        self.testloader = testloader
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # def weight_l2(self, model):
    #     # 计算L2正则化项
    #     l2_reg = torch.tensor(0., requires_grad=True).to(self.device)
    #     for param in model.parameters():
    #         l2_reg = l2_reg + torch.norm(param, 2)
    #     return l2_reg

    def weight_l1(self, model):
        # 计算L1正则化项
        l1_reg = torch.tensor(0., requires_grad=True).to(self.device)
        for param in model.parameters():
            l1_reg = l1_reg + torch.norm(param, 1)
        return l1_reg

    def calculate_sparsity(self, individual):
        total_weights = 0
        zero_weights = 0
        for param in individual.parameters():
            total_weights += param.numel()
            zero_weights += torch.sum(param == 0).item()

        sparsity = zero_weights / total_weights
        return sparsity

    # 定义训练函数
    def update(self, model, optimizer, trainloader, criterion):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        model.train()
        start_time = time.time()
        for batch_idx, (inputs, targets) in enumerate(trainloader):
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
        end_time = time.time()
        epoch_time = end_time - start_time

        return model, epoch_time

    #
    # def get_loss(self, model, loader):
    #     model.eval()
    #     test_loss = 0
    #     correct = 0
    #     total = 0
    #
    #     with torch.no_grad():
    #         for batch_idx, (inputs, targets) in enumerate(loader):
    #             inputs, targets = inputs.to(self.device), targets.to(self.device)
    #             outputs = model(inputs)
    #             loss = self.criterion(outputs, targets)
    #             test_loss += loss.item()
    #             _, predicted = outputs.max(1)
    #             total += targets.size(0)
    #             correct += predicted.eq(targets).sum().item()
    #
    #     test_loss /= len(loader)
    #
    #     return test_loss

    def fitness(self, population):
        # fitness加入参数的L1范数作为正则项
        Fitness = [get_loss(model, self.valloader, self.device, self.criterion) for model in population]
        return Fitness

    def fitness_sort(self, population):
        Fitness = self.fitness(population)
        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_individual = Fitness_sort[0][0]
        return best_individual, Fitness, Fitness_sort


    def sgd(self, sgd_optimizers, population, figure_save_path):

        # 训练模型
        train_losses_all, test_losses_all = [], []
        train_accs_all, test_accs_all = [], []
        valid_losses_all, valid_accs_all = [], []
        epoch_times_all, Weight_individual_all, Sparsity_weight_all = [], [], []

        Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list = [], [], [], [], [], []
        times, Weight_epoch, Sparsity_weight = [], [], []

        Weight, Sparsity_weight = [], []
        self.t = 0
        # checkpoint_dir = figure_save_path + '/SGD_checkpoints'  # 定义保存检查点的目录
        import os
        # os.makedirs(checkpoint_dir, exist_ok=True)  # 确保目录存在
        while self.t < self.num_epoch:
            print(f"Epoch [{self.t + 1}/{self.num_epoch}]")
            begin_time = time.time()
            updated_population = []
            loss = []
            train_losses, test_losses = [], []
            train_accs, test_accs = [], []
            valid_losses, valid_accs = [], []
            epoch_times, Weight_individual, Sparsity_weight_individual = [], [], []

            for i, (model, optimizer) in enumerate(zip(population, sgd_optimizers)):
                # 训练对比优化器
                update_model, epoch_time = self.update(model, optimizer, self.trainloader, self.criterion)
                updated_population.append(update_model)

                train_loss, train_acc = acc_loss(update_model, self.trainloader, self.device, self.criterion)
                loss.append(train_loss)
                test_loss, test_acc = acc_loss(update_model, self.testloader, self.device, self.criterion)
                valid_loss, valid_acc = acc_loss(update_model, self.valloader, self.device, self.criterion)

                weight = self.weight_l1(update_model)
                sparsity = self.calculate_sparsity(update_model)

                train_losses.append(train_loss)
                test_losses.append(test_loss)
                valid_losses.append(valid_loss)
                train_accs.append(train_acc)
                test_accs.append(test_acc)
                valid_accs.append(valid_acc)
                epoch_times.append(epoch_time)
                sparsity = self.calculate_sparsity(update_model)
                Sparsity_weight_individual.append(sparsity)

                Weight_individual.append(weight)
                print(
                    f" Individual {i + 1}: Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, "
                    f"Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.2f}%, "
                    f"Valid Loss: {valid_loss:.4f}, Valid Acc: {valid_acc:.2f}%, "
                    f"Weight: {weight:.4f}, Time: {epoch_time:.2f}s")

            end_time = time.time()
            sgd_epoch_time = end_time - begin_time

            train_losses_all.append(list(train_losses))
            test_losses_all.append(list(test_losses))
            valid_losses_all.append(list(valid_losses))
            train_accs_all.append(list(train_accs))
            test_accs_all.append(list(test_accs))
            valid_accs_all.append(list(valid_accs))
            epoch_times_all.append(list(epoch_times))
            Weight_individual_all.append(list(Weight_individual))
            Sparsity_weight_all.append(list(Sparsity_weight))

            population = updated_population
            best_individual, Fitness, Fitness_sort = self.fitness_sort(population)
            # individual_labels, sorted_indices = self.sort_population(Fitness)
            end_time = time.time()
            epoch_time_all = end_time - begin_time
            self.t += 1
            # if (self.t + 1) % 2 == 0:  # 假设checkpoint_interval是定义的保存间隔
            #     save_checkpoint(population, sgd_optimizers, self.t + 1, checkpoint_dir, train_losses_all, test_losses_all,
            #                     train_accs_all, test_accs_all,
            #                     valid_losses_all, valid_accs_all, epoch_times_all, Weight_individual_all,
            #                     Sparsity_weight_all)

            # 选择最优个体

            print("min fitness in validation data: {} ".format(np.min(Fitness)))
            test_loss_best, test_acc_best = acc_loss(best_individual, self.testloader, self.device, self.criterion)
            train_loss_best, train_acc_best = acc_loss(best_individual, self.trainloader, self.device, self.criterion)
            valid_loss_best, valid_acc_best = acc_loss(best_individual, self.valloader, self.device, self.criterion)
            Weight = self.weight_l1(best_individual)
            sparsity_best = self.calculate_sparsity(best_individual)

            print(
                f"Best Individual: Train Loss: {train_loss_best:.4f}, Train Acc: {train_acc_best:.2f}%, "
                f"Test Loss: {test_loss_best:.4f}, Test Acc: {test_acc_best:.2f}%, "
                f"Valid Loss: {valid_loss_best:.4f}, Valid Acc: {valid_acc_best:.2f}%, "
                f"Weight: {Weight:.4f},Weight sparsity: {sparsity_best:.4f},time_all:{epoch_time_all:.2f}s")

            # 存储每一代中最优个体的精度和损失

            Train_cost_list.append(train_loss_best)
            Test_cost_list.append(test_loss_best)
            Valid_cost_list.append(valid_loss_best)
            Train_Accuracy_list.append(train_acc_best)
            Test_Accuracy_list.append(test_acc_best)
            Valid_Accuracy_list.append(valid_acc_best)
            times.append(epoch_time_all)
            Weight_epoch.append(int(Weight))
            Sparsity_weight.append(sparsity_best)

        return train_losses_all, test_losses_all, valid_losses_all, train_accs_all, test_accs_all, valid_accs_all, \
               epoch_times_all, Weight_individual_all, Sparsity_weight_all, \
               Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, \
               Valid_Accuracy_list, times, Weight_epoch, Sparsity_weight

        #     sgd_train_losses.append(sgd_train_loss)
        #     sgd_test_losses.append(sgd_test_loss)
        #     sgd_train_accs.append(sgd_train_acc)
        #     sgd_test_accs.append(sgd_test_acc)
        #     sgd_valid_losses.append(sgd_valid_loss)
        #     sgd_valid_accs.append(sgd_valid_acc)
        #     sgd_epoch_times.append(sgd_epoch_time)
        #     Sparsity_weight.append(sparsity)
        #     Weight.append(int(weight))
        #     print(
        #         f"SGD: Train Loss: {sgd_train_loss:.4f}, Train Acc: {sgd_train_acc:.2f}%, "
        #         f"Test Loss: {sgd_test_loss:.4f}, Test Acc: {sgd_test_acc:.2f}%, "
        #         f"Valid Loss: {sgd_valid_loss:.4f}, Valid Acc: {sgd_valid_acc:.2f}%, "
        #         f"Weight: {weight:.4f},Sparsity Weight: {sparsity:.4f},Time: {sgd_epoch_time:.2f}s")
        #
        # return sgd_train_losses, sgd_test_losses, sgd_valid_losses, sgd_train_accs, \
        #        sgd_test_accs, sgd_valid_accs, sgd_epoch_times, Weight, Sparsity_weight
