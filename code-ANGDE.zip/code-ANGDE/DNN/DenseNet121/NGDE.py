import copy
import random
import time
import torch
from get_fitness import *
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from checkpoint import save_checkpoint

class NGDE():

    def __init__(self, trainloader, testloader, valloader, criterion,
                 population_size, F, fitness_p, niche_size, num_epoch):
        # self.optimizer = optimizer
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.trainloader = trainloader
        self.testloader = testloader
        self.valloader = valloader
        self.device = device
        self.criterion = criterion
        self.niche_size = niche_size
        self.lambda_reg = 0.001
        self.F = F
        self.fitness_p = fitness_p
        self.population_size = population_size
        self.num_epoch = num_epoch
        self.testloader = testloader
        self.t = 0

    # 定义计算损失函数
    def calculate_loss(self, model, inputs, targets):
        outputs = model(inputs)
        loss = self.criterion(outputs, targets)
        return loss, outputs


    # def weight_l2(self, model):
    #     # 计算L2正则化项
    #     l2_reg = torch.tensor(0., requires_grad=True).to(self.device)
    #     for param in model.parameters():
    #         l2_reg = l2_reg + torch.norm(param, 2)
    #     return l2_reg
    def weight_l1(self, model):
        # 计算L1正则化项
        l1_reg = torch.tensor(0., requires_grad=True).to(self.device)
        for param in model.parameters():
            l1_reg = l1_reg + torch.norm(param, 1)
        return l1_reg

    # 定义评估模型函数
    def evaluate_model(self, model, dataloader):
        model.eval()
        total_loss = 0
        correct = 0
        total = 0

        with torch.no_grad():
            for inputs, targets in dataloader:
                inputs, targets = inputs.to(self.device), targets.to(self.device)
                loss, outputs = self.calculate_loss(model, inputs, targets)
                total_loss += loss.item()
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()

        avg_loss = total_loss / len(dataloader)
        accuracy = 100.0 * correct / total

        return avg_loss, accuracy


    def prob(self, cost, Fitness):
        p = (cost - min(Fitness)) / (max(Fitness) - min(Fitness) + 10e-8)
        return p

    # 定义训练函数
    def NGDE_update1(self, model, optimizer):
        model.train()
        start_time = time.time()

        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(self.device), targets.to(self.device)
            # 参数更新
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = self.criterion(outputs, targets)

            loss.backward()
            optimizer.step()

        end_time = time.time()
        epoch_time = end_time - start_time

        return model, epoch_time


    def NGDE_update2(self, model, best_model, optimizer):
        model.train()
        start_time = time.time()

        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(self.device), targets.to(self.device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = self.criterion(outputs, targets)
            loss.backward()
            optimizer.step()

        with torch.no_grad():
            for param, best_param in zip(model.parameters(), best_model.parameters()):
                param.data = param.data + self.F * (best_param.data - param.data)

        end_time = time.time()
        epoch_time = end_time - start_time

        return model, epoch_time


    def NGDE_update3(self, population, model, optimizer, best_model):

        model.train()

        start_time = time.time()

        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(self.device), targets.to(self.device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = self.criterion(outputs, targets)
            loss.backward()
            optimizer.step()
        with torch.no_grad():
            j, k = random.sample(range(self.population_size), 2)
            xj, xk = population[j].parameters(), population[k].parameters()
            for param, best_param, param_j, param_k in zip(model.parameters(), best_model.parameters(), xj, xk):
                param.data = param.data + self.F * (best_param.data - param.data) + self.F * (param_j.data - param_k.data)

        end_time = time.time()
        epoch_time = end_time - start_time

        return model, epoch_time


    def update(self, model, best_model, population, fitness_model, Fitness, optimizer):
        # 对种群个体进行排序，按照Fitness值从小到大排序
        if fitness_model == np.min(Fitness):
            model_update, epoch_time = self.NGDE_update1(model, optimizer)
            return model_update, epoch_time
        else:
            p = self.prob(fitness_model, Fitness)
            if p > self.fitness_p:
                model_update, epoch_time = self.NGDE_update3(population, model, optimizer, best_model)
                return model_update, epoch_time
            else:
                model_update, epoch_time = self.NGDE_update2(model, best_model, optimizer)
                return model_update, epoch_time


    # def model_cosine_similarity(self, model1: nn.Module, model2: nn.Module)-> float:
    #     """计算两个模型之间的余弦相似度，并进行归一化处理。"""
    #     cos_sim = 0.0
    #     for param1, param2 in zip(model1.parameters(), model2.parameters()):
    #         cos_sim += F.cosine_similarity(param1.view(-1), param2.view(-1), dim=0).item()
    #     normalized_cos_sim = (cos_sim + 1) / 2
    #     return normalized_cos_sim

    def model_distance(self, model1: nn.Module, model2: nn.Module) -> float:
        """计算两个模型之间的欧氏距离（L2范数）。"""
        distance = 0.0
        for param1, param2 in zip(model1.parameters(), model2.parameters()):
            distance += torch.sum((param1 - param2) ** 2).item()
        return distance ** 0.5

    def distance_sort(self, individual, population):
        Distance = np.zeros(len(population))
        for i in range(len(population)):
            Distance[i] = self.model_distance(individual, population[i])

        Distance_sort = sorted(zip(population, Distance), key=lambda x: x[1], reverse=False)
        return Distance_sort

    def get_niche(self, population):
        Niche = []
        for i in range(int(self.population_size / self.niche_size)):
            best_individual, Fitness, Fitness_sort = self.fitness_sort(population)
            Distance_sort = self.distance_sort(best_individual, population)
            population1, niche = [], []
            for j in range(len(Distance_sort)):
                population1.append(Distance_sort[j][0])
            # print("niche size:", self.niche_size)
            for k in range(0, self.niche_size):
                niche.append(Distance_sort[k][0])
            Niche.append(niche)
            del population1[:self.niche_size]
            population = population1
        if len(population) != 0:
            Niche.append(population)
        return Niche


    # def calculate_average_cosine_similarity(self, population):
    #     """计算种群中所有个体间的平均距离。"""
    #     distance_sum = 0
    #     count = 0
    #     for i in range(len(population)):
    #         for j in range(i + 1, len(population)):
    #             distance_sum += self.model_cosine_similarity(population[i], population[j])
    #             count += 1
    #     return distance_sum / count if count > 0 else 0
    #
    # def get_niche(self, population):
    #     """根据距离因子动态设置阈值并划分小生境。"""
    #     average_distance = self.calculate_average_cosine_similarity(population)
    #     distance_factor = self.distance_factor_min + (self.distance_factor_max - self.distance_factor_min) * np.sqrt(
    #         self.t / self.num_epoch)
    #     distance_threshold = average_distance * distance_factor
    #
    #     niches = []
    #     for individual in population:
    #         niche_found = False
    #         for niche in niches:
    #             if self.model_cosine_similarity(individual, niche[0]) < distance_threshold:
    #                 niche.append(individual)
    #                 niche_found = True
    #                 break
    #
    #         if not niche_found:
    #             niches.append([individual])
    #
    #     return niches

    # def get_loss(self, model, loader):
    #     model.eval()
    #     test_loss = 0
    #     correct = 0
    #     total = 0
    #
    #     with torch.no_grad():
    #         for batch_idx, (inputs, targets) in enumerate(loader):
    #             inputs, targets = inputs.to(self.device), targets.to(self.device)
    #             outputs = model(inputs)
    #             loss = self.criterion(outputs, targets)
    #
    #             test_loss += loss.item()
    #             _, predicted = outputs.max(1)
    #             total += targets.size(0)
    #             correct += predicted.eq(targets).sum().item()
    #
    #     test_loss /= len(loader)
    #
    #     return test_loss


    def fitness(self, population):
        ## fitness加入参数的L2范数作为正则项
        Fitness = [get_loss(model, self.valloader, self.device, self.criterion) for model in population]
        return Fitness

    def fitness_sort(self, population):
        Fitness = self.fitness(population)
        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        # print(Fitness_sort)
        best_individual = Fitness_sort[0][0]
        return best_individual, Fitness, Fitness_sort

    def Near_select(self, individual1, cost1, population):#, offspring_population):
        d_sort = self.distance_sort(individual1, population)
        individual_nearest = d_sort[1][0]
        cost_nearest = get_loss(individual_nearest,self.valloader, self.device, self.criterion)
        if cost1 <= cost_nearest:
            return individual1
        else:
            return individual_nearest
            # offspring_population.append(individual1)
        # else:
        #     offspring_population.append(individual_nearest)
        # return offspring_population

    # def select(self,  Fitness_sort):
    #     # 选择前50%最优个体和随机选取50%个体作为下一代
    #     next_generation = []
    #     new_fitness = []
    #     num_best_selected = self.population_size // 2
    #     num_random_selected = self.population_size - num_best_selected
    #
    #     # 选择前50%最优个体
    #     next_generation.extend([individual for individual, fitness in Fitness_sort[0:num_best_selected]])
    #     new_fitness.extend([fitness for individual, fitness in Fitness_sort[0:num_best_selected]])
    #
    #     # 随机选取50%个体
    #     remaining_individuals = [individual for individual, fitness in Fitness_sort[num_best_selected:]]
    #     remaining_fitness = [fitness for individual, fitness in Fitness_sort[num_best_selected:]]
    #     random_indices = np.random.choice(len(remaining_individuals), num_random_selected, replace=False)
    #     next_generation.extend([remaining_individuals[i] for i in random_indices])
    #     new_fitness.extend([remaining_fitness[i] for i in random_indices])
    #
    #     # 更新种群
    #     population = next_generation
    #     return population, new_fitness

    def calculate_sparsity(self, individual):
        total_weights = 0
        zero_weights = 0
        for param in individual.parameters():
            total_weights += param.numel()
            zero_weights += torch.sum(param == 0).item()

        sparsity = zero_weights / total_weights
        return sparsity

    def NGDE(self, optimizers, population, figure_save_path):

        # 训练模型
        train_losses_all, test_losses_all = [], []
        train_accs_all, test_accs_all = [], []
        valid_losses_all, valid_accs_all = [], []
        epoch_times_all, Weight_individual_all = [], []
        Sparsity_weight_all = []
        # individual_labels = [0] * self.population_size


        Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list = [], [], [], [], [], []
        times, Weight_epoch, Sparsity_weight_epoch = [],[],[]
        Fitness_list, Niche_all, num_Niche = [], [], []


        best_individual, Fitness, Fitness_sort = self.fitness_sort(population)
        print("Fitness:", Fitness)
        # checkpoint_dir = figure_save_path + '/NGDE_checkpoints'  # 定义保存检查点的目录
        import os
        # os.makedirs(checkpoint_dir, exist_ok=True)  # 确保目录存在
        while self.t < self.num_epoch:
            print(f"Epoch [{self.t + 1}/{self.num_epoch}]")
            loss = []
            updated_population = []
            train_losses, test_losses = [], []
            train_accs, test_accs = [], []
            valid_losses, valid_accs = [], []
            epoch_times, Weight_individual = [], []
            Sparsity_weight_individual = []

            begin_time = time.time()
            Niche = self.get_niche(population)
            Niche_all.append(Niche)
            num_Niche.append(len(Niche))
            # offspring_population = population
            offspring_population_L = []
            # print(len(Niche))
            for n in range(len(Niche)):
                niche = Niche[n]
                best_individual, Fitness, Fitness_sort = self.fitness_sort(niche)
                for i, (model, optimizer) in enumerate(zip(niche, optimizers)):
                    fitness_model = get_loss(model, self.valloader, self.device, self.criterion)
                    update_model, epoch_time = self.update(model, best_individual, population, fitness_model, Fitness, optimizer)

                    offspring_individual = update_model
                    cost1 = get_loss(offspring_individual, self.valloader, self.device, self.criterion)
                    model_offspring = self.Near_select(offspring_individual, cost1, population)
                    offspring_population_L.append(model_offspring)

                    train_loss, train_acc = acc_loss(model_offspring, self.trainloader, self.device, self.criterion)
                    loss.append(train_loss)
                    test_loss, test_acc = acc_loss(model_offspring, self.testloader, self.device, self.criterion)
                    valid_loss, valid_acc = acc_loss(model_offspring, self.valloader, self.device, self.criterion)
                    weight = self.weight_l1(model_offspring)
                    sparsity = self.calculate_sparsity(model_offspring)
                    Sparsity_weight_individual.append(sparsity)

                    train_losses.append(train_loss)
                    test_losses.append(test_loss)
                    valid_losses.append(valid_loss)
                    train_accs.append(train_acc)
                    test_accs.append(test_acc)
                    valid_accs.append(valid_acc)
                    epoch_times.append(epoch_time)
                    Weight_individual.append(int(weight))

                    print(
                        f"Niche {n + 1}, Individual {i + 1}: Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, "
                        f"Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.2f}%, "
                        f"Valid Loss: {valid_loss:.4f}, Valid Acc: {valid_acc:.2f}%, "
                        f"Weight: {weight:.4f}, Time: {epoch_time:.2f}s")


            population = offspring_population_L

            train_losses_all.append(list(train_losses))
            test_losses_all.append(list(test_losses))
            valid_losses_all.append(list(valid_losses))
            train_accs_all.append(list(train_accs))
            test_accs_all.append(list(test_accs))
            valid_accs_all.append(list(valid_accs))
            epoch_times_all.append(list(epoch_times))
            Weight_individual_all.append(list(Weight_individual))
            Sparsity_weight_all.append(list(Sparsity_weight_individual))

            best_individual, Fitness, Fitness_sort = self.fitness_sort(updated_population + population)
            # population, Fitness = self.select(Fitness_sort)
            # individual_labels, sorted_indices = self.sort_population(Fitness)
            end_time = time.time()
            epoch_time_all = end_time - begin_time
            self.t += 1
            # if (self.t + 1) % 2 == 0:  # 假设checkpoint_interval是定义的保存间隔
            #     save_checkpoint(population, optimizers, self.t + 1, checkpoint_dir, train_losses_all, test_losses_all,
            #                     train_accs_all, test_accs_all,
            #                     valid_losses_all, valid_accs_all, epoch_times_all, Weight_individual_all,
            #                     Sparsity_weight_all)

            # 选择最优个体
            print("min fitness in validation data: {} ".format(np.min(Fitness)))
            test_loss_best, test_acc_best = acc_loss(best_individual, self.testloader, self.device, self.criterion)
            train_loss_best, train_acc_best = acc_loss(best_individual, self.trainloader, self.device, self.criterion)
            valid_loss_best, valid_acc_best = acc_loss(best_individual, self.valloader, self.device, self.criterion)
            Weight = self.weight_l1(best_individual)

            sparsity_best = self.calculate_sparsity(best_individual)
            Sparsity_weight_epoch.append(sparsity_best)

            # 存储每一代中最优个体的精度和损失

            Train_cost_list.append(train_loss_best)
            Test_cost_list.append(test_loss_best)
            Valid_cost_list.append(valid_loss_best)
            Train_Accuracy_list.append(train_acc_best)
            Test_Accuracy_list.append(test_acc_best)
            Valid_Accuracy_list.append(valid_acc_best)
            times.append(epoch_time_all)
            Weight_epoch.append(int(Weight))

            print(
                f"Best Individual: Train Loss: {train_loss_best:.4f}, Train Acc: {train_acc_best:.2f}%, "
                f"Test Loss: {test_loss_best:.4f}, Test Acc: {test_acc_best:.2f}%, "
                f"Valid Loss: {valid_loss_best:.4f}, Valid Acc: {valid_acc_best:.2f}%, "
                f"Weight: {Weight:.4f},Weight sparsity: {sparsity_best:.4f},time_all:{epoch_time_all:.2f}s")


        return train_losses_all, test_losses_all, valid_losses_all, train_accs_all, test_accs_all, valid_accs_all, \
               epoch_times_all, Weight_individual_all, Sparsity_weight_all, \
               Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, \
               Valid_Accuracy_list, times, Weight_epoch, num_Niche, Sparsity_weight_epoch


