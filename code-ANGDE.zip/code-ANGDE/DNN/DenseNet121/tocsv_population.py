import pandas as pd

def tocsv_population(train_losses_all, test_losses_all, valid_losses_all, train_accs_all, test_accs_all, valid_accs_all,
          epoch_times_all, Weight_individual_all):


    # ==================================store=========================================
    for i in range(population_size):
        new_list = [sublist[i] for sublist in list_all]
        print("Individual ", i," :",  new_list)
        plt.plot(epochs, new_list, label=f"Individual {i + 1}")





    pd_msgd = pd.DataFrame([Valid_cost_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Valid_cost_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Valid_cost_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Valid_cost_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Valid_cost_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Valid_cost_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Valid_cost-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Valid_Accuracy_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Valid_Accuracy_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Valid_Accuracy_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Valid_Accuracy_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Valid_Accuracy_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Valid_Accuracy_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Valid_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Train_Accuracy_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Train_Accuracy_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Train_Accuracy_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Train_Accuracy_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Train_Accuracy_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Train_Accuracy_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Train_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Train_cost_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Train_cost_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Train_cost_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Train_cost_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Train_cost_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Train_cost_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Train_cost-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Test_Accuracy_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Test_Accuracy_list[1]], index=["ESGD"])
    pd_de = pd.DataFrame([Test_Accuracy_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Test_Accuracy_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Test_Accuracy_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Test_Accuracy_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Test_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Test_cost_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Test_cost_list[1]], index=["Adam"])
    pd_de = pd.DataFrame([Test_cost_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Test_cost_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Test_cost_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Test_cost_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Test_cost-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Weight_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Weight_list[1]], index=["Adam"])
    pd_de = pd.DataFrame([Weight_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Weight_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Weight_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Weight_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Weight-" + dataname + ".xlsx"
    history.to_excel(path)




