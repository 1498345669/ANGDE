import copy
import random
import time
import torch
import math
from CNN import *
from get_fitness import *
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import os
from checkpoint import save_checkpoint
import torch.nn.utils.prune as prune



class INGDE():

    def __init__(self, trainloader, testloader, valloader, criterion,lambda_reg,
                 population_size, F_min, F_max, distance_factor_max, distance_factor_min, fitness_p, num_epoch):
        # self.optimizer = optimizer
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.trainloader = trainloader
        self.testloader = testloader
        self.valloader = valloader
        self.device = device
        self.criterion = criterion
        self.lambda_reg = lambda_reg
        self.F_min = F_min
        self.F_max = F_max
        self.fitness_p = fitness_p
        self.population_size = population_size
        # self.prune_threshold = 1e-3
        self.num_epoch = num_epoch
        self.testloader = testloader
        self.distance_factor_max = distance_factor_max
        self.distance_factor_min = distance_factor_min
        self.t = 0

    # # 定义计算损失函数
    # def calculate_loss(self, model, inputs, targets):
    #     outputs = model(inputs)
    #     loss = self.criterion(outputs, targets)
    #     # # 计算L1正则化项
    #     # l1_reg = torch.tensor(0., requires_grad=False).to(self.device)
    #     # for param in model.parameters():
    #     #     l1_reg += torch.norm(param, 1)
    #     #     # 将L1正则化项加入到损失中
    #     # loss += self.lambda_reg * l1_reg
    #     # 定义一个小的正数epsilon
    #     epsilon = 1e-8
    #
    #     # 计算修改后的L1正则化项
    #     l1_reg = torch.tensor(0., requires_grad=False).to(self.device)
    #     for param in model.parameters():
    #         l1_reg += torch.sum(torch.sqrt(param ** 2 + epsilon))
    #
    #         # 将修改后的L1正则化项加入到损失中
    #     loss += self.lambda_reg * l1_reg
    #     return loss, outputs

    def weight_l1(self, model):
        # 计算L1正则化项
        l1_reg = torch.tensor(0., requires_grad=False).to(self.device)
        for param in model.parameters():
            l1_reg += torch.norm(param, 1)
        return l1_reg

    def count_parameters(self, model):
        return sum(p.numel() for p in model.parameters() if p.requires_grad)

    def prob(self, cost, Fitness):
        p = (cost - min(Fitness)) / (max(Fitness) - min(Fitness) + 10e-8)
        return p

    def adaptive_F(self, p):
        F = self.F_min + (self.F_max - self.F_min) * p
        return F


    def INGDE_update1(self, model, optimizer):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        model.train()
        start_time = time.time()
        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = self.criterion(outputs, targets)

            # epsilon = 1e-8
            # l1_reg = torch.tensor(0., requires_grad=False).to(self.device)
            # for param in model.parameters():
            #     l1_reg += torch.sum(torch.sqrt(param ** 2 + epsilon))
            # loss = loss + self.lambda_reg * l1_reg
            # lambda_l1 = 1e-5  # L1 正则化系数
            l1_norm = sum(p.abs().sum() for p in model.parameters())
            loss = loss + self.lambda_reg * l1_norm

            loss.backward()
            optimizer.step()
        end_time = time.time()
        epoch_time = end_time - start_time

        return model, epoch_time

    def DE_best_random(self, population, model, best_model, F2):
        with torch.no_grad():
            j, k = random.sample(range(self.population_size), 2)
            xj, xk = population[j].parameters(), population[k].parameters()
            for param, best_param, param_j, param_k in zip(model.parameters(), best_model.parameters(), xj, xk):
                param.data = param.data + F2 * (best_param.data - param.data) + F2 * (param_j.data - param_k.data)
        return model

    def DE_best(self, model, best_model, F1):
        with torch.no_grad():
            for param, best_param in zip(model.parameters(), best_model.parameters()):
                param.data = param.data + F1 * (best_param.data - param.data)
        return model

    def model_gradient(self, model, optimizer):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        model.train()
        for batch_idx, (inputs, targets) in enumerate(self.trainloader):
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = self.criterion(outputs, targets)
            #
            l1_norm = sum(p.abs().sum() for p in model.parameters())
            loss = loss + self.lambda_reg * l1_norm

            loss.backward()
            optimizer.step()
        return model




    def INGDE_update2(self, model, best_model, optimizer, F1):
        model.train()
        start_time = time.time()

        model_best = self.DE_best(model, best_model, F1)
        model_update = self.model_gradient(model_best, optimizer)


        # for batch_idx, (inputs, targets) in enumerate(self.trainloader):
        #     inputs, targets = inputs.to(self.device), targets.to(self.device)
        #     with torch.no_grad():
        #         for param, best_param in zip(model.parameters(), best_model.parameters()):
        #             param.data = param.data + F1 * (best_param.data - param.data)
        #
        #     outputs = model(inputs)
        #     loss = self.criterion(outputs, targets)
        #     # epsilon = 1e-8
        #     # l1_reg = torch.tensor(0., requires_grad=False).to(self.device)
        #     # for param in model.parameters():
        #     #     l1_reg += torch.sum(torch.sqrt(param ** 2 + epsilon))
        #     # loss = loss + self.lambda_reg * l1_reg
        #     # lambda_l1 = 1e-5  # L1 正则化系数
        #     l1_norm = sum(p.abs().sum() for p in model.parameters())
        #     loss = loss + self.lambda_reg * l1_norm
        #
        #     loss.backward()
        #     optimizer.step()

        end_time = time.time()
        epoch_time = end_time - start_time

        return model_update, epoch_time


    def INGDE_update3(self, population, model, optimizer, best_model, F2):
        model.train()
        start_time = time.time()

        model_best = self.DE_best_random(population, model, best_model, F2)
        model_update = self.model_gradient(model_best, optimizer)

        # for batch_idx, (inputs, targets) in enumerate(self.trainloader):
        #     inputs, targets = inputs.to(self.device), targets.to(self.device)
        #     with torch.no_grad():
        #         j, k = random.sample(range(self.population_size), 2)
        #         # print(j,k)
        #         xj, xk = population[j].parameters(), population[k].parameters()
        #         for param, best_param, param_j, param_k in zip(model.parameters(), best_model.parameters(), xj, xk):
        #             # print("param.shape:",param.shape, "paramj.shape:", param_j.shape, "paramk.shape:", param_k.shape)
        #             param.data = param.data + F2 * (param_j.data - param_k.data)+ F2 * (best_param.data - param.data)
        #
        #
        #     outputs = model(inputs)
        #     loss = self.criterion(outputs, targets)
        #     # epsilon = 1e-8
        #     # l1_reg = torch.tensor(0., requires_grad=False).to(self.device)
        #     # for param in model.parameters():
        #     #     l1_reg += torch.sum(torch.sqrt(param ** 2 + epsilon))
        #     # loss = loss + self.lambda_reg * l1_reg
        #     lambda_l1 = 1e-5  # L1 正则化系数
        #     l1_norm = sum(p.abs().sum() for p in model.parameters())
        #     loss = loss + lambda_l1 * l1_norm

            # loss.backward()
            # optimizer.step()
        end_time = time.time()
        epoch_time = end_time - start_time

        return model_update, epoch_time


    def update(self, model, best_model, population, Fitness, optimizer, n_class):

        # model_parameters = model.state_dict()
        # model_parent = LeNet5(n_class).to(self.device)
        # model_parent.load_state_dict(model_parameters)

        fitness_model = get_loss(model, self.valloader, self.device, self.criterion)
        if model == best_model:
            model_update, epoch_time = self.INGDE_update1(model, optimizer)
            model_update_fitness = get_loss(model_update, self.valloader, self.device, self.criterion)
            print("fitness:", fitness_model, "; update by Adam:", model_update_fitness)
            return model_update, epoch_time, model_update_fitness
        else:
            p = self.prob(fitness_model, Fitness)
            F = self.adaptive_F(p)
            if p > self.fitness_p:
                model_update,  epoch_time = self.INGDE_update3(population, model, optimizer, best_model, F)
                model_update_fitness = get_loss(model_update, self.valloader, self.device, self.criterion)
                print("fitness:", fitness_model, "; update by random:", model_update_fitness)
                # if fitness_model >= model_update_fitness:
                return model_update, epoch_time, model_update_fitness
                # else:
                    # return model_parent, epoch_time,  fitness_model
            else:
                model_update,  epoch_time = self.INGDE_update2(model, best_model, optimizer, F)
                model_update_fitness = get_loss(model_update, self.valloader, self.device, self.criterion)
                print("fitness:", fitness_model, "; update by best:", model_update_fitness)
                # if fitness_model >= model_update_fitness:
                return model_update, epoch_time, model_update_fitness
                # else:
                #     return model_parent, epoch_time,  fitness_model


    def model_cosine_similarity(self, model1: nn.Module, model2: nn.Module)-> float:
        cos_sim_sum = 0.0
        param_count = 0
        for param1, param2 in zip(model1.parameters(), model2.parameters()):
            cos_sim = F.cosine_similarity(param1.view(-1), param2.view(-1), dim=0).item()
            cos_sim_sum += cos_sim
            param_count += 1

        average_cos_sim = cos_sim_sum / param_count if param_count > 0 else 0
        normalized_cos_sim = (average_cos_sim + 1) / 2
        return normalized_cos_sim


    def calculate_average_cosine_similarity(self, population):
        distance_sum = 0
        count = 0
        for i in range(len(population)):
            for j in range(i + 1, len(population)):
                distance_sum += self.model_cosine_similarity(population[i], population[j])
                count += 1
        return distance_sum / count if count > 0 else 0


    def get_niche(self, population):
        average_distance = self.calculate_average_cosine_similarity(population)
        distance_factor = self.distance_factor_min + (self.distance_factor_max - self.distance_factor_min) * np.sqrt(self.t / self.num_epoch)
        distance_threshold = average_distance * distance_factor

        print("average distance:", average_distance, "; distance factor:", distance_factor, "; distance_threshold:", distance_threshold)

        niches = []
        for individual in population:
            niche_found = False
            for niche in niches:
                cos_sim = self.model_cosine_similarity(individual, niche[0])
                if cos_sim > distance_threshold:
                    niche.append(individual)
                    niche_found = True
                    break

            if not niche_found:
                niches.append([individual])

        return niches

    def fitness(self, population):
        Fitness = [get_loss(model, self.valloader, self.device, self.criterion) for model in population]
        return Fitness

    def fitness_sort(self, population):
        Fitness = self.fitness(population)
        Fitness_sort = sorted(zip(population, Fitness), key=lambda x: x[1], reverse=False)
        best_individual = Fitness_sort[0][0]
        return best_individual, Fitness, Fitness_sort

    def population_sort(self, Fitness):
        min_fitness = min(Fitness)
        min_index = Fitness.index(min_fitness)
        return min_fitness, min_index

    def calculate_sparsity(self, individual):
        total_weights = 0
        zero_weights = 0
        for param in individual.parameters():
            total_weights += param.numel()
            zero_weights += torch.sum(param == 0).item()

        sparsity = zero_weights / total_weights
        return sparsity

    # 定义剪枝函数
    def prune_model(self, model, amount):
        parameters_to_prune = []
        for module in model.modules():
            if isinstance(module, nn.Linear):
                parameters_to_prune.append((module, 'weight'))
        prune.global_unstructured(parameters_to_prune, pruning_method=prune.L1Unstructured, amount=amount)

        return model

    def select(self,  Fitness_sort):
        # 选择前50%最优个体和随机选取50%个体作为下一代
        next_generation = []
        new_fitness = []
        num_best_selected = self.population_size // 2
        num_random_selected = self.population_size - num_best_selected

        # 选择前50%最优个体
        next_generation.extend([individual for individual, fitness in Fitness_sort[0:num_best_selected]])
        new_fitness.extend([fitness for individual, fitness in Fitness_sort[0:num_best_selected]])

        # 随机选取50%个体
        remaining_individuals = [individual for individual, fitness in Fitness_sort[num_best_selected:]]
        remaining_fitness = [fitness for individual, fitness in Fitness_sort[num_best_selected:]]
        random_indices = np.random.choice(len(remaining_individuals), num_random_selected, replace=False)
        next_generation.extend([remaining_individuals[i] for i in random_indices])
        new_fitness.extend([remaining_fitness[i] for i in random_indices])

        # 更新种群
        population = next_generation
        return population, new_fitness

    def copy_population(self, n_class, population):
        population_copy = []
        for model in population:
            model_parameters = model.state_dict()
            model_parent = DenseNet121(n_class).to(self.device)
            model_parent.load_state_dict(model_parameters)
            population_copy.append(model_parent)
        return population_copy

    def INGDE(self, optimizers, population, figure_save_path, n_class):

        # 训练模型
        train_losses_all, test_losses_all = [], []
        train_accs_all, test_accs_all = [], []
        valid_losses_all, valid_accs_all = [], []
        epoch_times_all, Weight_individual_all, Sparsity_weight_all = [], [],[]


        Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, Valid_Accuracy_list = [], [], [], [], [], []
        times, Weight_epoch, Sparsity_weight = [],[],[]
        Fitness_list, Niche_all, num_Niche = [], [], []

        best_individual, Fitness, Fitness_sort = self.fitness_sort(population)
        print("Fitness:", Fitness)

        # checkpoint_dir = figure_save_path + '/INGDE_checkpoints'  # 定义保存检查点的目录
        # os.makedirs(checkpoint_dir, exist_ok=True)  # 确保目录存在

        while self.t < self.num_epoch:
            print(f"Epoch [{self.t + 1}/{self.num_epoch}]")
            # loss = []
            population_copy = self.copy_population(n_class, population)
            updated_population = []
            train_losses, test_losses = [], []
            train_accs, test_accs = [], []
            valid_losses, valid_accs = [], []
            epoch_times, Weight_individual, Sparsity_weight_individual = [], [],[]

            begin_time = time.time()
            Niche = self.get_niche(population)
            Niche_all.append(Niche)
            print("the number of niche:", len(Niche))
            num_Niche.append(len(Niche))
            for n in range(len(Niche)):
                niche = Niche[n]
                best_individual, Fitness, Fitness_sort = self.fitness_sort(niche)
                for i, (model, optimizer) in enumerate(zip(niche, optimizers)):
                    select_update_model, select_epoch_time, select_update_fitness = self.update(model, best_individual, population, Fitness, optimizer, n_class)
                    updated_population.append(select_update_model)

                    test_loss, test_acc = acc_loss(select_update_model, self.testloader, self.device, self.criterion)
                    valid_loss, valid_acc = acc_loss(select_update_model, self.valloader, self.device, self.criterion)
                    train_loss, train_acc = acc_loss(select_update_model, self.trainloader, self.device, self.criterion)
                    weight = self.weight_l1(select_update_model)

                    # updated_population.append(select_update_model)
                    train_losses.append(train_loss)
                    test_losses.append(test_loss)
                    valid_losses.append(valid_loss)
                    train_accs.append(train_acc)
                    test_accs.append(test_acc)
                    valid_accs.append(valid_acc)
                    epoch_times.append(select_epoch_time)
                    sparsity = self.calculate_sparsity(select_update_model)
                    Sparsity_weight_individual.append(sparsity)

                    Weight_individual.append(weight)

                    # 计算参数量
                    total_params = sum(p.numel() for p in select_update_model.parameters() if p.requires_grad)
                    print(
                        f"Niche {n + 1}, Individual {i + 1}: Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, "
                        f"Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.2f}%, "
                        f"Valid Loss: {valid_loss:.4f}, Valid Acc: {valid_acc:.2f}%, "
                        f"Weight: {weight:.4f}, Time: {select_epoch_time:.2f}s")
                    print(f'Total number of parameters: {total_params}')


            # best_individual, Fitness, Fitness_sort = self.fitness_sort(updated_population + population_copy)
            # population, Fitness = self.select(Fitness_sort)
            population = updated_population
            end_time = time.time()
            epoch_time_all = end_time - begin_time
            self.t += 1

            # 选择最优个体
            print("min fitness in validation data: {} ".format(np.min(Fitness)))
            test_loss_best, test_acc_best = acc_loss(best_individual, self.testloader, self.device, self.criterion)
            train_loss_best, train_acc_best = acc_loss(best_individual, self.trainloader, self.device,
                                                       self.criterion)
            valid_loss_best, valid_acc_best = acc_loss(best_individual, self.valloader, self.device, self.criterion)
            Weight = self.weight_l1(best_individual)

            # 存储每一代中最优个体的精度和损失

            sparsity_best = self.calculate_sparsity(best_individual)



            Train_cost_list.append(train_loss_best)
            Test_cost_list.append(test_loss_best)
            Valid_cost_list.append(valid_loss_best)
            Train_Accuracy_list.append(train_acc_best)
            Test_Accuracy_list.append(test_acc_best)
            Valid_Accuracy_list.append(valid_acc_best)
            times.append(epoch_time_all)
            Weight_epoch.append(int(Weight))
            Sparsity_weight.append(sparsity_best)

            print(
                f"Best Individual: Train Loss: {train_loss_best:.4f}, Train Acc: {train_acc_best:.2f}%, "
                f"Test Loss: {test_loss_best:.4f}, Test Acc: {test_acc_best:.2f}%, "
                f"Valid Loss: {valid_loss_best:.4f}, Valid Acc: {valid_acc_best:.2f}%, "
                f"Weight: {Weight:.4f},Weight sparsity: {sparsity_best:.4f},time_all:{epoch_time_all:.2f}s")


            train_losses_all.append(list(train_losses))
            test_losses_all.append(list(test_losses))
            valid_losses_all.append(list(valid_losses))
            train_accs_all.append(list(train_accs))
            test_accs_all.append(list(test_accs))
            valid_accs_all.append(list(valid_accs))
            epoch_times_all.append(list(epoch_times))
            Weight_individual_all.append(list(Weight_individual))
            Sparsity_weight_all.append(list(Sparsity_weight))

        return train_losses_all, test_losses_all, valid_losses_all, train_accs_all, test_accs_all, valid_accs_all, \
               epoch_times_all, Weight_individual_all, Sparsity_weight_all, \
               Train_Accuracy_list, Train_cost_list, Test_Accuracy_list, Test_cost_list, Valid_cost_list, \
               Valid_Accuracy_list, times, Weight_epoch, num_Niche, Sparsity_weight


