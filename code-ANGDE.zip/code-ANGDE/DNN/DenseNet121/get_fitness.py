import time
import torch


def get_loss(model, loader, device, criterion):
    model.eval()
    test_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(loader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

    test_loss /= len(loader)
    # test_acc = 100.0 * correct / total

    return test_loss

def get_loss_reg(model, loader, device, criterion, lambda_reg):
    model.eval()
    test_loss_reg = 0

    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(loader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)

            # 计算L2正则化项
            l1_reg = torch.tensor(0., requires_grad=True).to(device)
            for param in model.parameters():
                l1_reg = l1_reg + torch.norm(param, 1)
            # 将L1正则化项加入到损失中
            loss = loss + (lambda_reg) * l1_reg

            test_loss_reg += loss.item()

    test_loss_reg /= len(loader)
    return test_loss_reg


def acc_loss(model, loader, device, criterion):
    model.eval()
    test_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(loader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

    test_loss /= len(loader)
    test_acc = 100.0 * correct / total

    return test_loss, test_acc

#
# # 定义训练函数
# def train_acc_loss(model, optimizer, trainloader, device, criterion):
#     model.train()
#     train_loss = 0
#     correct = 0
#     total = 0
#     start_time = time.time()
#
#     for batch_idx, (inputs, targets) in enumerate(trainloader):
#         inputs, targets = inputs.to(device), targets.to(device)
#         optimizer.zero_grad()
#         outputs = model(inputs)
#         loss = criterion(outputs, targets)
#         loss.backward()
#         optimizer.step()
#
#         train_loss += loss.item()
#         _, predicted = outputs.max(1)
#         total += targets.size(0)
#         correct += predicted.eq(targets).sum().item()
#
#     end_time = time.time()
#     epoch_time = end_time - start_time
#
#     train_loss /= len(trainloader)
#     train_acc = 100.0 * correct / total
#
#     return train_loss, train_acc, epoch_time
#

