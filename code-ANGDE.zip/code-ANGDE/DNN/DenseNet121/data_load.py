# import copy
# import torchvision
# import torch
# import torch.nn as nn
# import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from torch.utils.data import Subset, random_split


def num_class(train_loader):
    class_set = set()
    for images, labels in train_loader:
        for label in labels:
            class_set.add(label.item())
    num_classes = len(class_set)
    return num_classes


def choose_dataset(name, batch_size):
    if name == 'MNIST':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))])

        full_dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.MNIST(root='./data', train=False, transform=transform)
        train_size = int(0.8 * len(full_dataset))  # 使用80%的数据作为训练集
        val_size = len(full_dataset) - train_size

        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = num_class(train_loader)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'MNIST_100':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))])

        full_dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.MNIST(root='./data', train=False, transform=transform)


        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(200))
        train_dataset = Subset(full_dataset, indices[:100])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[100:200])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:100])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'MNIST_1000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))])

        full_dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.MNIST(root='./data', train=False, transform=transform)


        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(2000))
        train_dataset = Subset(full_dataset, indices[:1000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[1000:2000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'MNIST_5000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))])

        full_dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.MNIST(root='./data', train=False, transform=transform)


        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(6000))
        train_dataset = Subset(full_dataset, indices[:5000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[5000:6000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'MNIST_10000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))])

        full_dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.MNIST(root='./data', train=False, transform=transform)


        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(11000))
        train_dataset = Subset(full_dataset, indices[:10000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[10000:11000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'FashionMNIST':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))])

        full_dataset = datasets.FashionMNIST(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.FashionMNIST(root='./data', train=False, download=True, transform=transform)
        train_size = int(0.8 * len(full_dataset))  # 使用80%的数据作为训练集
        val_size = len(full_dataset) - train_size

        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = num_class(train_loader)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'FashionMNIST_1000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))])

        full_dataset = datasets.FashionMNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.FashionMNIST(root='./data', train=False, transform=transform)


        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(2000))
        train_dataset = Subset(full_dataset, indices[:1000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[1000:2000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'FashionMNIST_5000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))])

        full_dataset = datasets.FashionMNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.FashionMNIST(root='./data', train=False, transform=transform)


        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(6000))
        train_dataset = Subset(full_dataset, indices[:5000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[5000:6000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'FashionMNIST_10000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))])

        full_dataset = datasets.FashionMNIST(root='./data', train=True, transform=transform, download=True)
        test_dataset = datasets.FashionMNIST(root='./data', train=False, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(11000))
        train_dataset = Subset(full_dataset, indices[:10000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[10000:11000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR10':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
        # 加载测试集
        test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

        # 划分训练集和验证集
        train_size = int(0.8 * len(full_dataset))  # 使用80%的数据作为训练集
        val_size = len(full_dataset) - train_size

        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR10_100':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(200))
        train_dataset = Subset(full_dataset, indices[:100])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[100:200])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:100])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR10_1000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(2000))
        train_dataset = Subset(full_dataset, indices[:1000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[1000:2000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR10_5000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(6000))
        train_dataset = Subset(full_dataset, indices[:5000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[5000:6000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR10_10000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(11000))
        train_dataset = Subset(full_dataset, indices[:10000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[10000:11000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes


    elif name == 'CIFAR100':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        full_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
        # 加载测试集
        test_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

        # 划分训练集和验证集
        train_size = int(0.8 * len(full_dataset))  # 使用80%的数据作为训练集
        val_size = len(full_dataset) - train_size

        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR100_100':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(200))
        train_dataset = Subset(full_dataset, indices[:100])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[100:200])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:100])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR100_1000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(2000))
        train_dataset = Subset(full_dataset, indices[:1000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[1000:2000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR100_5000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(6000))
        train_dataset = Subset(full_dataset, indices[:5000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[5000:6000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'CIFAR100_10000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        # 加载 CIFAR-10 数据集
        full_dataset = datasets.CIFAR100(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR100(root='./data', train=False, download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(11000))
        train_dataset = Subset(full_dataset, indices[:10000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[10000:11000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'STL10':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        full_dataset = datasets.STL10(root='./data', split='train', download=True, transform=transform)
        # 加载测试集
        test_dataset = datasets.STL10(root='./data', split='test', download=True, transform=transform)

        # 划分训练集和验证集
        train_size = int(0.8 * len(full_dataset))  # 使用80%的数据作为训练集
        val_size = len(full_dataset) - train_size

        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'SVHN':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        full_dataset = datasets.SVHN(root='./data', split='train', download=True, transform=transform)
        test_dataset = datasets.SVHN(root='./data', split='test', download=True, transform=transform)


        # 划分训练集和验证集
        train_size = int(0.8 * len(full_dataset))  # 使用80%的数据作为训练集
        val_size = len(full_dataset) - train_size

        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
        # 获取类别数量
        num_classes = num_class(train_loader)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'SVHN_1000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        full_dataset = datasets.SVHN(root='./data', split='train', download=True, transform=transform)
        test_dataset = datasets.SVHN(root='./data', split='test', download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(2000))
        train_dataset = Subset(full_dataset, indices[:1000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[1000:2000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = num_class(train_loader)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'SVHN_5000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        full_dataset = datasets.SVHN(root='./data', split='train', download=True, transform=transform)
        test_dataset = datasets.SVHN(root='./data', split='test', download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(6000))
        train_dataset = Subset(full_dataset, indices[:5000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[5000:6000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = num_class(train_loader)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'SVHN_10000':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

        full_dataset = datasets.SVHN(root='./data', split='train', download=True, transform=transform)
        test_dataset = datasets.SVHN(root='./data', split='test', download=True, transform=transform)

        # 仅选择前100个样本作为训练集、验证集和测试集
        indices = list(range(11000))
        train_dataset = Subset(full_dataset, indices[:10000])  # 70个样本作为训练集
        val_dataset = Subset(full_dataset, indices[10000:11000])  # 15个样本作为验证集
        test_dataset = Subset(test_dataset, indices[:1000])  # 15个样本作为测试集

        # 创建数据加载器
        # batch_size = 10
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = num_class(train_loader)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'STL10':
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        full_dataset = datasets.STL10(root='./data', split='train', download=True, transform=transform)
        # 加载测试集
        test_dataset = datasets.STL10(root='./data', split='test', download=True, transform=transform)

        # 划分训练集和验证集
        train_size = int(0.8 * len(full_dataset))  # 使用80%的数据作为训练集
        val_size = len(full_dataset) - train_size

        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

        # 获取类别数量
        num_classes = len(full_dataset.classes)

        return train_dataset, val_dataset, test_dataset, train_loader, val_loader, test_loader, num_classes

    elif name == 'VIT-CIFAR10':
        transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

        train_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
        n = num_class(train_loader)

        return train_dataset, test_dataset, train_loader, test_loader, n



    else:
        print("数据集名称错误")
