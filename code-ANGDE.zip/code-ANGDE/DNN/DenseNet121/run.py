from run_method import *


# 定义超参数
population_size = 5
niche_size = 2
num_epochs = 50
gd_epochs = 1
evo_epochs = 1
batch_size = 64
lambda_reg = 0.0001
# lr_adam = 0.001
# lr_sgd = 0.001
# fitness_p = 0.5
prev_best_loss = float('inf')  # 自定义学习率


print(torch.__version__)

print(torch.cuda.is_available())

import os

os.environ['CUDA_VISIBLE_DEVICES'] = '1'

#=============================
random.seed(123)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# if not torch.cuda.is_available():
#     raise RuntimeError("CUDA is not available. Please check your CUDA installation.")

LR = [0.0001, 0.001]
FP = [0.5, 0.1, 0.01]
F = 0.05
F_min = 0.01
F_max = 0.1
distance_factor_max, distance_factor_min = 1.0, 0.5
fitness_p_ngde = 0.1

for fitness_p in FP:
    for lr_sgd in LR:
        for lr_adam in LR:
            for lr_ingde in LR:
                figure_save_path = "0902_results_fp" + str(fitness_p) + "[F_min, F_max]" + str([F_min, F_max]) \
                                   + "[lr_ingde, lr_adam, lr_sgd]" + str([lr_ingde, lr_adam, lr_sgd]) \
                                   + "[df_max, df_min]" + str([distance_factor_max, distance_factor_min]) + "CIFAR10"
                # =============================
                dataname = "CIFAR10_5000"
                run_method(dataname, batch_size, device, population_size, lr_ingde, lr_sgd, lr_adam, num_epochs, fitness_p, fitness_p_ngde, F, niche_size, lambda_reg,
               F_min, F_max, gd_epochs, evo_epochs, distance_factor_max, distance_factor_min, figure_save_path)
                # =============================
                dataname = "CIFAR10_10000"
                run_method(dataname, batch_size, device, population_size, lr_ingde, lr_sgd, lr_adam, num_epochs, fitness_p, fitness_p_ngde, F, niche_size, lambda_reg,
               F_min, F_max, gd_epochs, evo_epochs, distance_factor_max, distance_factor_min, figure_save_path)
                # =============================
                dataname = "CIFAR10"
                run_method(dataname, batch_size, device, population_size, lr_ingde, lr_sgd, lr_adam, num_epochs, fitness_p, fitness_p_ngde, F, niche_size, lambda_reg,
               F_min, F_max, gd_epochs, evo_epochs, distance_factor_max, distance_factor_min, figure_save_path)
