import pandas as pd


def tocsv(run_time, run_onetime, figure_save_path, dataname, Train_Accuracy_list, Train_cost_list,
          Test_Accuracy_list, Test_cost_list, Valid_Accuracy_list, Valid_cost_list, Weight_list, SparsityWeight_list):
    # ==================================time====================
    print("runtime:")
    print("SGD: {}min; ADAM: {}min; DE: {}min; ESGD:{}min; NGDE: {}min; INGDE: {}min; ".format(run_time[0], run_time[1], run_time[2], run_time[3], run_time[4], run_time[5]))

    index = ["SGD", "ADAM", "DE", "ESGD", "NGDE", "INGDE"]
    columns = ["runtime"]
    running_time = pd.DataFrame(run_time, index=index, columns=columns)
    path = figure_save_path + "/runtime-" + dataname + ".xlsx"
    running_time.to_excel(path)
    # running_time.to_csv(path.replace('.xlsx', '.csv'))
    # ==================================time====================
    print("once runtime:")
    print("SGD: {}min; ADAM: {}min; DE: {}min; ESGD:{}min; NGDE: {}min; INGDE: {}min; ".format(run_onetime[0], run_onetime[1],
                                                                                               run_onetime[2], run_onetime[3],
                                                                                               run_onetime[4],
                                                                                               run_onetime[5]))
    index = ["SGD", "ADAM", "DE", "ESGD", "NGDE", "INGDE"]
    columns = ["once runtime"]
    running_time = pd.DataFrame(run_time, index=index, columns=columns)
    path = figure_save_path + "/once runtime-" + dataname + ".xlsx"
    running_time.to_excel(path)

    # ==================================store=========================================
    pd_msgd = pd.DataFrame([Valid_cost_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Valid_cost_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Valid_cost_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Valid_cost_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Valid_cost_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Valid_cost_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Valid_cost-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Valid_Accuracy_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Valid_Accuracy_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Valid_Accuracy_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Valid_Accuracy_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Valid_Accuracy_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Valid_Accuracy_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Valid_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Train_Accuracy_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Train_Accuracy_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Train_Accuracy_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Train_Accuracy_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Train_Accuracy_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Train_Accuracy_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Train_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Train_cost_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Train_cost_list[1]], index=["ADAM"])
    pd_de = pd.DataFrame([Train_cost_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Train_cost_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Train_cost_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Train_cost_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Train_cost-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Test_Accuracy_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Test_Accuracy_list[1]], index=["ESGD"])
    pd_de = pd.DataFrame([Test_Accuracy_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Test_Accuracy_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Test_Accuracy_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Test_Accuracy_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Test_Accuracy-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Test_cost_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Test_cost_list[1]], index=["Adam"])
    pd_de = pd.DataFrame([Test_cost_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Test_cost_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Test_cost_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Test_cost_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Test_cost-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([Weight_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([Weight_list[1]], index=["Adam"])
    pd_de = pd.DataFrame([Weight_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([Weight_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([Weight_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([Weight_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/Weight-" + dataname + ".xlsx"
    history.to_excel(path)

    pd_msgd = pd.DataFrame([SparsityWeight_list[0]], index=["SGD"])
    pd_madam = pd.DataFrame([SparsityWeight_list[1]], index=["Adam"])
    pd_de = pd.DataFrame([SparsityWeight_list[2]], index=["DE"])
    pd_esgd = pd.DataFrame([SparsityWeight_list[3]], index=["ESGD"])
    pd_ngde = pd.DataFrame([SparsityWeight_list[4]], index=["NGDE"])
    pd_ingde = pd.DataFrame([SparsityWeight_list[5]], index=["INGDE"])
    history = pd.concat([pd_msgd, pd_madam, pd_de, pd_esgd, pd_ngde, pd_ingde])
    path = figure_save_path + "/SparsityWeight_list-" + dataname + ".xlsx"
    history.to_excel(path)




