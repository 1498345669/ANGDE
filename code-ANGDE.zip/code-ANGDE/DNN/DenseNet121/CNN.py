
from torchvision.models import resnet18, vgg16, mobilenet_v2, densenet121
import torch.nn as nn


# def MonileNetV2(n):
#     model = mobilenet_v2(pretrained=False)
#     num_ftrs = model.classifier[1].in_features
#     model.classifier[1] = nn.Linear(num_ftrs, n)
#     return model
#
def DenseNet121(n):
    model = densenet121(pretrained=False)
    # 修改最后一层全连接层的输出维度为 10 (CIFAR-10 有 10 个类别)
    num_ftrs = model.classifier.in_features
    model.classifier = nn.Linear(num_ftrs, n)
    return model



#
# # ##创建一个MobileNetV2模型，并将其最后一层全连接层的输出维度修改为10，以适应CIFAR-10数据集（10个类别）
# # def CIFAR10_MobileNetV2():
# #     model = mobilenet_v2(pretrained=False)
# #     num_ftrs = model.classifier[1].in_features
# #     model.classifier[1] = nn.Linear(num_ftrs, 10)
# #     return model
# #
# # ##创建一个MobileNetV2模型，并将其最后一层全连接层的输出维度修改为100，以适应CIFAR-100数据集（100个类别）
# # def CIFAR100_MobileNetV2():
# #     model = mobilenet_v2(pretrained=False)
# #     num_ftrs = model.classifier[1].in_features
# #     model.classifier[1] = nn.Linear(num_ftrs, 100)
# #     return model
#
#
# # ## 创建一个DenseNet121模型，并将其最后一层全连接层的输出维度修改为10，以适应CIFAR-10数据集
# # def CIFAR10_DenseNet121():
# #     model = densenet121(pretrained=False)
# #     # 修改最后一层全连接层的输出维度为 10 (CIFAR-10 有 10 个类别)
# #     num_ftrs = model.classifier.in_features
# #     model.classifier = nn.Linear(num_ftrs, 10)
# #     return model
# #
# #
# # def CIFAR100_DenseNet121():
# #     model = densenet121(pretrained=False)
# #     # 修改最后一层全连接层的输出维度为 100 (CIFAR-100 有 100 个类别)
# #     num_ftrs = model.classifier.in_features
# #     model.classifier = nn.Linear(num_ftrs, 100)
# #     return model

